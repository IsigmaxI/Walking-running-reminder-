package com.abdulla.runwalk;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HistoryActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupSystemBars();
        buildUi();
    }

    private void buildUi() {
        FrameLayout screen = new FrameLayout(this);
        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.bg_runwalk);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        screen.addView(bg, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        View overlay = new View(this);
        overlay.setBackgroundColor(Color.parseColor("#C0000000"));
        screen.addView(overlay, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        ScrollView scrollView = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(20), dp(30), dp(20), dp(24));
        scrollView.addView(root);

        TextView title = new TextView(this);
        title.setText("Progress & History");
        title.setTextColor(Color.WHITE);
        title.setTextSize(32);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrapParams());

        List<WorkoutHistory.Entry> items = WorkoutHistory.getAll(this);
        int completedCount = WorkoutHistory.completedCount(this);
        int targetSessions = 24;
        int progress = Math.min(100, Math.round((completedCount * 100f) / targetSessions));
        double totalDistance = WorkoutHistory.totalDistanceMeters(this);
        double totalCalories = WorkoutHistory.totalCalories(this);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(makeRoundBg("#CC0D1927", dp(26), "#2F4E6B", dp(1)));
        LinearLayout.LayoutParams cardParams = matchWrapParams();
        cardParams.setMargins(0, dp(18), 0, dp(14));
        root.addView(card, cardParams);

        TextView progressText = new TextView(this);
        progressText.setText("8-week plan progress: " + progress + "%\n" + completedCount + " of " + targetSessions + " workouts completed");
        progressText.setTextColor(Color.WHITE);
        progressText.setTextSize(18);
        progressText.setTypeface(Typeface.DEFAULT_BOLD);
        progressText.setGravity(Gravity.CENTER);
        card.addView(progressText, matchWrapParams());

        ProgressBar progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(progress);
        LinearLayout.LayoutParams pbParams = matchHeightParams(dp(12));
        pbParams.setMargins(0, dp(14), 0, dp(14));
        card.addView(progressBar, pbParams);

        LinearLayout totalsRow = new LinearLayout(this);
        totalsRow.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(totalsRow, matchWrapParams());
        totalsRow.addView(makeStat("Total Distance", formatDistance(totalDistance)), weightedParams());
        totalsRow.addView(makeStat("Total Calories", Math.round(totalCalories) + " kcal"), weightedParams());

        TextView listTitle = new TextView(this);
        listTitle.setText("Workout History");
        listTitle.setTextColor(Color.parseColor("#B7FBE0"));
        listTitle.setTextSize(20);
        listTitle.setTypeface(Typeface.DEFAULT_BOLD);
        listTitle.setGravity(Gravity.CENTER);
        listTitle.setPadding(0, dp(10), 0, dp(10));
        root.addView(listTitle, matchWrapParams());

        if (items.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No workouts yet. Finish your first session to see it here.");
            empty.setTextColor(Color.parseColor("#B9C6D6"));
            empty.setTextSize(16);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(12), dp(20), dp(12), dp(20));
            root.addView(empty, matchWrapParams());
        } else {
            SimpleDateFormat df = new SimpleDateFormat("dd MMM yyyy • HH:mm", Locale.getDefault());
            for (WorkoutHistory.Entry e : items) {
                LinearLayout item = new LinearLayout(this);
                item.setOrientation(LinearLayout.VERTICAL);
                item.setPadding(dp(14), dp(12), dp(14), dp(12));
                item.setBackground(makeRoundBg("#AA102033", dp(20), "#263B56", dp(1)));
                LinearLayout.LayoutParams itemParams = matchWrapParams();
                itemParams.setMargins(0, dp(6), 0, dp(6));
                root.addView(item, itemParams);

                TextView top = new TextView(this);
                top.setText("Week " + e.week + (e.completed ? " • Complete" : " • Stopped"));
                top.setTextColor(Color.WHITE);
                top.setTextSize(17);
                top.setTypeface(Typeface.DEFAULT_BOLD);
                item.addView(top, matchWrapParams());

                TextView date = new TextView(this);
                date.setText(df.format(new Date(e.dateMs)));
                date.setTextColor(Color.parseColor("#B7FBE0"));
                date.setTextSize(13);
                item.addView(date, matchWrapParams());

                TextView details = new TextView(this);
                details.setText(formatDuration(e.totalMs) + " • " + formatDistance(e.distanceMeters) + " • " + Math.round(e.calories) + " kcal");
                details.setTextColor(Color.parseColor("#B9C6D6"));
                details.setTextSize(15);
                details.setPadding(0, dp(6), 0, 0);
                item.addView(details, matchWrapParams());
            }
        }

        screen.addView(scrollView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(screen);
    }

    private TextView makeStat(String label, String value) {
        TextView v = new TextView(this);
        v.setText(label + "\n" + value);
        v.setTextColor(Color.WHITE);
        v.setTextSize(15);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(8), dp(12), dp(8), dp(12));
        v.setBackground(makeRoundBg("#801A2B3A", dp(18), "#334C62", dp(1)));
        return v;
    }

    private String formatDuration(long millis) {
        long seconds = Math.max(0, millis / 1000);
        long minutes = seconds / 60;
        long sec = seconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, sec);
    }

    private String formatDistance(double meters) {
        if (meters >= 1000) return String.format(Locale.getDefault(), "%.2f km", meters / 1000.0);
        return Math.round(meters) + " m";
    }

    private void setupSystemBars() {
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.setStatusBarColor(Color.parseColor("#07111F"));
            window.setNavigationBarColor(Color.parseColor("#07111F"));
        }
    }

    private GradientDrawable makeRoundBg(String color, int radius, String strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.parseColor(color));
        drawable.setCornerRadius(radius);
        if (strokeColor != null) drawable.setStroke(strokeWidth, Color.parseColor(strokeColor));
        return drawable;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout.LayoutParams matchWrapParams() { return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams matchHeightParams(int height) { return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height); }
    private LinearLayout.LayoutParams weightedParams() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1); p.setMargins(dp(4), dp(4), dp(4), dp(4)); return p; }
}
