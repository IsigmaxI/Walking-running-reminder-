package com.abdulla.runwalk;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class WorkoutHistory {
    private static final String PREFS = "runwalk_history";
    private static final String KEY_ITEMS = "items";
    private static final int MAX_ITEMS = 100;

    public static class Entry {
        public long dateMs;
        public int week;
        public long totalMs;
        public long jogMs;
        public long walkMs;
        public double calories;
        public double distanceMeters;
        public boolean completed;
    }

    public static void add(Context context, Entry entry) {
        List<Entry> items = getAll(context);
        items.add(0, entry);
        while (items.size() > MAX_ITEMS) items.remove(items.size() - 1);
        saveAll(context, items);
    }

    public static List<Entry> getAll(Context context) {
        List<Entry> list = new ArrayList<>();
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_ITEMS, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                Entry e = new Entry();
                e.dateMs = o.optLong("date_ms");
                e.week = o.optInt("week");
                e.totalMs = o.optLong("total_ms");
                e.jogMs = o.optLong("jog_ms");
                e.walkMs = o.optLong("walk_ms");
                e.calories = o.optDouble("calories");
                e.distanceMeters = o.optDouble("distance_m");
                e.completed = o.optBoolean("completed");
                list.add(e);
            }
        } catch (Exception ignored) { }
        return list;
    }

    private static void saveAll(Context context, List<Entry> items) {
        JSONArray array = new JSONArray();
        try {
            for (Entry e : items) {
                JSONObject o = new JSONObject();
                o.put("date_ms", e.dateMs);
                o.put("week", e.week);
                o.put("total_ms", e.totalMs);
                o.put("jog_ms", e.jogMs);
                o.put("walk_ms", e.walkMs);
                o.put("calories", e.calories);
                o.put("distance_m", e.distanceMeters);
                o.put("completed", e.completed);
                array.put(o);
            }
        } catch (Exception ignored) { }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_ITEMS, array.toString())
                .apply();
    }

    public static int completedCount(Context context) {
        int count = 0;
        for (Entry e : getAll(context)) if (e.completed) count++;
        return count;
    }

    public static double totalDistanceMeters(Context context) {
        double total = 0;
        for (Entry e : getAll(context)) total += e.distanceMeters;
        return total;
    }

    public static double totalCalories(Context context) {
        double total = 0;
        for (Entry e : getAll(context)) total += e.calories;
        return total;
    }
}
