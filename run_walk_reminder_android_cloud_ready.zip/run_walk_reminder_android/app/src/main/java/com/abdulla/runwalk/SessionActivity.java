package com.abdulla.runwalk;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class SessionActivity extends Activity {
    private LinearLayout root;
    private TextView intervalText;
    private TextView timerText;
    private TextView stepText;
    private TextView hintText;
    private TextView stopConfirmText;
    private ProgressBar progressBar;
    private LinearLayout stopConfirmBox;
    private CountDownTimer countDownTimer;
    private List<Interval> intervals;
    private int currentIndex = 0;
    private int week = 1;
    private boolean isStopping = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setupSystemBars();

        week = getIntent().getIntExtra("week", 1);
        intervals = getIntervalsForWeek(week);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(28), dp(24), dp(28));
        root.setBackgroundColor(Color.parseColor("#07111F"));

        TextView title = new TextView(this);
        title.setText("Week " + week + " Session");
        title.setTextColor(Color.parseColor("#B9C6D6"));
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(14));
        root.addView(title, matchWrapParams());

        intervalText = new TextView(this);
        intervalText.setTextSize(44);
        intervalText.setTypeface(Typeface.DEFAULT_BOLD);
        intervalText.setGravity(Gravity.CENTER);
        intervalText.setPadding(0, dp(22), 0, dp(22));
        root.addView(intervalText, matchWrapParams());

        timerText = new TextView(this);
        timerText.setTextColor(Color.WHITE);
        timerText.setTextSize(68);
        timerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        timerText.setGravity(Gravity.CENTER);
        timerText.setPadding(0, dp(14), 0, dp(10));
        root.addView(timerText, matchWrapParams());

        stepText = new TextView(this);
        stepText.setTextColor(Color.parseColor("#B9C6D6"));
        stepText.setTextSize(17);
        stepText.setGravity(Gravity.CENTER);
        stepText.setPadding(0, 0, 0, dp(14));
        root.addView(stepText, matchWrapParams());

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(intervals.size());
        LinearLayout.LayoutParams progressParams = matchHeightParams(dp(12));
        progressParams.setMargins(0, dp(4), 0, dp(22));
        root.addView(progressBar, progressParams);

        hintText = new TextView(this);
        hintText.setTextColor(Color.parseColor("#8EA0B6"));
        hintText.setTextSize(15);
        hintText.setGravity(Gravity.CENTER);
        hintText.setPadding(dp(12), dp(14), dp(12), dp(14));
        hintText.setBackground(makeRoundBg("#102033", dp(18), "#1D314B", dp(1)));
        root.addView(hintText, matchWrapParams());

        Button stopButton = new Button(this);
        stopButton.setText("Stop Session");
        stopButton.setTextSize(17);
        stopButton.setTypeface(Typeface.DEFAULT_BOLD);
        stopButton.setTextColor(Color.WHITE);
        stopButton.setAllCaps(false);
        stopButton.setBackground(makeRoundBg("#D94040", dp(22), null, 0));
        LinearLayout.LayoutParams stopParams = matchHeightParams(dp(56));
        stopParams.setMargins(0, dp(28), 0, 0);
        root.addView(stopButton, stopParams);
        stopButton.setOnClickListener(v -> showStopConfirmation());

        stopConfirmBox = new LinearLayout(this);
        stopConfirmBox.setOrientation(LinearLayout.VERTICAL);
        stopConfirmBox.setPadding(dp(16), dp(14), dp(16), dp(16));
        stopConfirmBox.setBackground(makeRoundBg("#25151A", dp(22), "#FF6B6B", dp(1)));
        stopConfirmBox.setVisibility(View.GONE);
        LinearLayout.LayoutParams confirmParams = matchWrapParams();
        confirmParams.setMargins(0, dp(14), 0, 0);

        stopConfirmText = new TextView(this);
        stopConfirmText.setText("اسحب السلايدر للآخر لتأكيد إيقاف التمرين");
        stopConfirmText.setTextColor(Color.WHITE);
        stopConfirmText.setTextSize(15);
        stopConfirmText.setGravity(Gravity.CENTER);
        stopConfirmText.setPadding(0, 0, 0, dp(10));
        stopConfirmBox.addView(stopConfirmText, matchWrapParams());

        SeekBar stopSlider = new SeekBar(this);
        stopSlider.setMax(100);
        stopSlider.setProgress(0);
        stopConfirmBox.addView(stopSlider, matchHeightParams(dp(48)));
        stopSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && progress >= 96) confirmStopAndFinish();
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (!isStopping && seekBar.getProgress() < 96) {
                    seekBar.setProgress(0);
                    stopConfirmText.setText("اسحب السلايدر للآخر لتأكيد إيقاف التمرين");
                }
            }
        });

        Button cancelStopButton = new Button(this);
        cancelStopButton.setText("Cancel");
        cancelStopButton.setTextSize(15);
        cancelStopButton.setAllCaps(false);
        cancelStopButton.setTextColor(Color.WHITE);
        cancelStopButton.setBackground(makeRoundBg("#223248", dp(18), null, 0));
        LinearLayout.LayoutParams cancelParams = matchHeightParams(dp(46));
        cancelParams.setMargins(0, dp(8), 0, 0);
        stopConfirmBox.addView(cancelStopButton, cancelParams);
        cancelStopButton.setOnClickListener(v -> {
            stopSlider.setProgress(0);
            stopConfirmBox.setVisibility(View.GONE);
        });

        root.addView(stopConfirmBox, confirmParams);

        setContentView(root);
        startCurrentInterval();
    }

    private void showStopConfirmation() {
        if (stopConfirmBox.getVisibility() == View.VISIBLE) {
            stopConfirmText.setText("اسحب السلايدر للآخر لتأكيد إيقاف التمرين");
            return;
        }
        stopConfirmBox.setVisibility(View.VISIBLE);
        stopConfirmText.setText("اسحب السلايدر للآخر لتأكيد إيقاف التمرين");
    }

    private void confirmStopAndFinish() {
        if (isStopping) return;
        isStopping = true;
        if (countDownTimer != null) countDownTimer.cancel();
        Toast.makeText(this, "Session stopped", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void startCurrentInterval() {
        if (currentIndex >= intervals.size()) {
            playAlarm();
            Toast.makeText(this, "Finished. Good job!", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        Interval interval = intervals.get(currentIndex);
        boolean isJog = "JOG".equals(interval.type);
        int accent = Color.parseColor(isJog ? "#00D084" : "#FFB020");
        int darkCard = Color.parseColor(isJog ? "#123323" : "#3A2912");

        intervalText.setText(isJog ? "JOG" : "WALK");
        intervalText.setTextColor(accent);
        intervalText.setBackground(makeRoundBg(String.format("#%06X", (0xFFFFFF & darkCard)), dp(28), isJog ? "#1EEA91" : "#FFC45D", dp(1)));
        stepText.setText("Step " + (currentIndex + 1) + " of " + intervals.size());
        hintText.setText(isJog ? "هرولة خفيفة — لا تسرع، خلك قادر تتكلم" : "مشي وهدّي النفس — استعد للتبديل القادم");
        progressBar.setProgress(currentIndex + 1);
        playAlarm();

        countDownTimer = new CountDownTimer(interval.durationMs, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timerText.setText(formatTime(millisUntilFinished));
            }

            @Override
            public void onFinish() {
                currentIndex++;
                startCurrentInterval();
            }
        };
        countDownTimer.start();
    }

    private String formatTime(long millis) {
        long totalSeconds = (millis + 999) / 1000;
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private void playAlarm() {
        try {
            ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
            tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500);
        } catch (Exception ignored) { }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) countDownTimer.cancel();
    }

    private List<Interval> getIntervalsForWeek(int week) {
        switch (week) {
            case 1: return repeat(8, 60, 90);
            case 2: return repeat(7, 90, 120);
            case 3: return repeat(6, 120, 120);
            case 4: return repeat(5, 180, 120);
            case 5: return repeat(4, 300, 120);
            case 6: return repeat(3, 480, 120);
            case 7: return repeat(3, 600, 120);
            case 8:
                List<Interval> list = new ArrayList<>();
                list.add(new Interval("JOG", 25 * 60 * 1000L));
                return list;
            default: return repeat(8, 60, 90);
        }
    }

    private List<Interval> repeat(int times, int jogSeconds, int walkSeconds) {
        List<Interval> list = new ArrayList<>();
        for (int i = 0; i < times; i++) {
            list.add(new Interval("JOG", jogSeconds * 1000L));
            list.add(new Interval("WALK", walkSeconds * 1000L));
        }
        return list;
    }

    private void setupSystemBars() {
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.setStatusBarColor(Color.parseColor("#07111F"));
            window.setNavigationBarColor(Color.parseColor("#07111F"));
        }
    }

    private GradientDrawable makeRoundBg(String color, int radius, String strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.parseColor(color));
        drawable.setCornerRadius(radius);
        if (strokeColor != null) drawable.setStroke(strokeWidth, Color.parseColor(strokeColor));
        return drawable;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams matchWrapParams() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchHeightParams(int height) {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height);
    }

    private static class Interval {
        final String type;
        final long durationMs;
        Interval(String type, long durationMs) {
            this.type = type;
            this.durationMs = durationMs;
        }
    }
}
