package com.abdulla.runwalk;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

public class SessionActivity extends Activity {
    private TextView intervalText;
    private TextView timerText;
    private TextView stepText;
    private TextView caloriesText;
    private TextView hintText;
    private TextView stopConfirmText;
    private ProgressBar progressBar;
    private LinearLayout stopConfirmBox;
    private int week = 1;
    private boolean isStopping = false;
    private boolean summaryOpened = false;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    private final Runnable uiTicker = new Runnable() {
        @Override
        public void run() {
            updateFromService();
            if (!summaryOpened) uiHandler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupSystemBars();

        week = getIntent().getIntExtra("week", 1);
        buildUi();
        startWorkoutServiceIfNeeded();
        uiHandler.post(uiTicker);
    }

    private void buildUi() {
        FrameLayout screen = new FrameLayout(this);

        ImageView backgroundImage = new ImageView(this);
        backgroundImage.setImageResource(R.drawable.bg_runwalk);
        backgroundImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        screen.addView(backgroundImage, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        View darkOverlay = new View(this);
        darkOverlay.setBackgroundColor(Color.parseColor("#C0000000"));
        screen.addView(darkOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(28), dp(24), dp(28));
        root.setBackgroundColor(Color.TRANSPARENT);

        TextView title = new TextView(this);
        title.setText("Week " + week + " Session");
        title.setTextColor(Color.parseColor("#B9C6D6"));
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(14));
        root.addView(title, matchWrapParams());

        intervalText = new TextView(this);
        intervalText.setTextSize(44);
        intervalText.setTypeface(Typeface.DEFAULT_BOLD);
        intervalText.setGravity(Gravity.CENTER);
        intervalText.setPadding(0, dp(22), 0, dp(22));
        root.addView(intervalText, matchWrapParams());

        timerText = new TextView(this);
        timerText.setTextColor(Color.WHITE);
        timerText.setTextSize(68);
        timerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        timerText.setGravity(Gravity.CENTER);
        timerText.setPadding(0, dp(14), 0, dp(10));
        root.addView(timerText, matchWrapParams());

        stepText = new TextView(this);
        stepText.setTextColor(Color.parseColor("#B9C6D6"));
        stepText.setTextSize(17);
        stepText.setGravity(Gravity.CENTER);
        stepText.setPadding(0, 0, 0, dp(8));
        root.addView(stepText, matchWrapParams());

        caloriesText = new TextView(this);
        caloriesText.setTextColor(Color.parseColor("#B7FBE0"));
        caloriesText.setTextSize(18);
        caloriesText.setTypeface(Typeface.DEFAULT_BOLD);
        caloriesText.setGravity(Gravity.CENTER);
        caloriesText.setPadding(dp(12), dp(10), dp(12), dp(10));
        caloriesText.setBackground(makeRoundBg("#123323", dp(18), "#244B39", dp(1)));
        LinearLayout.LayoutParams calorieParams = matchWrapParams();
        calorieParams.setMargins(0, 0, 0, dp(14));
        root.addView(caloriesText, calorieParams);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(16);
        LinearLayout.LayoutParams progressParams = matchHeightParams(dp(12));
        progressParams.setMargins(0, dp(4), 0, dp(22));
        root.addView(progressBar, progressParams);

        hintText = new TextView(this);
        hintText.setTextColor(Color.parseColor("#8EA0B6"));
        hintText.setTextSize(15);
        hintText.setGravity(Gravity.CENTER);
        hintText.setPadding(dp(12), dp(14), dp(12), dp(14));
        hintText.setBackground(makeRoundBg("#102033", dp(18), "#1D314B", dp(1)));
        root.addView(hintText, matchWrapParams());

        Button stopButton = new Button(this);
        stopButton.setText("Stop Session");
        stopButton.setTextSize(17);
        stopButton.setTypeface(Typeface.DEFAULT_BOLD);
        stopButton.setTextColor(Color.WHITE);
        stopButton.setAllCaps(false);
        stopButton.setBackground(makeRoundBg("#D94040", dp(22), null, 0));
        LinearLayout.LayoutParams stopParams = matchHeightParams(dp(56));
        stopParams.setMargins(0, dp(28), 0, 0);
        root.addView(stopButton, stopParams);
        stopButton.setOnClickListener(v -> showStopConfirmation());

        stopConfirmBox = new LinearLayout(this);
        stopConfirmBox.setOrientation(LinearLayout.VERTICAL);
        stopConfirmBox.setPadding(dp(16), dp(14), dp(16), dp(16));
        stopConfirmBox.setBackground(makeRoundBg("#25151A", dp(22), "#FF6B6B", dp(1)));
        stopConfirmBox.setVisibility(View.GONE);
        LinearLayout.LayoutParams confirmParams = matchWrapParams();
        confirmParams.setMargins(0, dp(14), 0, 0);

        stopConfirmText = new TextView(this);
        stopConfirmText.setText("اسحب السلايدر للآخر لتأكيد إيقاف التمرين");
        stopConfirmText.setTextColor(Color.WHITE);
        stopConfirmText.setTextSize(15);
        stopConfirmText.setGravity(Gravity.CENTER);
        stopConfirmText.setPadding(0, 0, 0, dp(10));
        stopConfirmBox.addView(stopConfirmText, matchWrapParams());

        SeekBar stopSlider = new SeekBar(this);
        stopSlider.setMax(100);
        stopSlider.setProgress(0);
        stopConfirmBox.addView(stopSlider, matchHeightParams(dp(48)));
        stopSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && progress >= 96) confirmStopAndOpenSummary();
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (!isStopping && seekBar.getProgress() < 96) {
                    seekBar.setProgress(0);
                    stopConfirmText.setText("اسحب السلايدر للآخر لتأكيد إيقاف التمرين");
                }
            }
        });

        Button cancelStopButton = new Button(this);
        cancelStopButton.setText("Cancel");
        cancelStopButton.setTextSize(15);
        cancelStopButton.setAllCaps(false);
        cancelStopButton.setTextColor(Color.WHITE);
        cancelStopButton.setBackground(makeRoundBg("#223248", dp(18), null, 0));
        LinearLayout.LayoutParams cancelParams = matchHeightParams(dp(46));
        cancelParams.setMargins(0, dp(8), 0, 0);
        stopConfirmBox.addView(cancelStopButton, cancelParams);
        cancelStopButton.setOnClickListener(v -> {
            stopSlider.setProgress(0);
            stopConfirmBox.setVisibility(View.GONE);
        });

        root.addView(stopConfirmBox, confirmParams);

        screen.addView(root, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        setContentView(screen);
    }

    private void startWorkoutServiceIfNeeded() {
        if (WorkoutService.isRunning()) return;
        Intent intent = new Intent(this, WorkoutService.class);
        intent.setAction(WorkoutService.ACTION_START);
        intent.putExtra("week", week);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
        else startService(intent);
    }

    private void updateFromService() {
        WorkoutService.Snapshot s = WorkoutService.getSnapshot();
        if (s == null) {
            intervalText.setText("READY");
            timerText.setText("00:00");
            stepText.setText("Starting timer...");
            caloriesText.setText("Calories: 0 kcal");
            hintText.setText("Keep this notification active so the workout continues when the screen is locked.");
            return;
        }

        if (s.finished) {
            openSummaryOnce();
            return;
        }

        boolean isJog = "JOG".equals(s.intervalType);
        int accent = Color.parseColor(isJog ? "#00D084" : "#FFB020");
        int darkCard = Color.parseColor(isJog ? "#123323" : "#3A2912");
        intervalText.setText(isJog ? "JOG" : "WALK");
        intervalText.setTextColor(accent);
        intervalText.setBackground(makeRoundBg(String.format("#%06X", (0xFFFFFF & darkCard)), dp(28), isJog ? "#1EEA91" : "#FFC45D", dp(1)));
        timerText.setText(formatTime(s.remainingMs));
        stepText.setText("Step " + s.step + " of " + s.totalSteps);
        caloriesText.setText("Calories: " + Math.round(s.calories) + " kcal");
        progressBar.setMax(Math.max(1, s.totalSteps));
        progressBar.setProgress(Math.max(1, s.step));
        hintText.setText(isJog ? "هرولة خفيفة — لا تسرع، خلك قادر تتكلم" : "مشي وهدّي النفس — استعد للتبديل القادم");
    }

    private void showStopConfirmation() {
        if (stopConfirmBox.getVisibility() == View.VISIBLE) {
            stopConfirmText.setText("اسحب السلايدر للآخر لتأكيد إيقاف التمرين");
            return;
        }
        stopConfirmBox.setVisibility(View.VISIBLE);
        stopConfirmText.setText("اسحب السلايدر للآخر لتأكيد إيقاف التمرين");
    }

    private void confirmStopAndOpenSummary() {
        if (isStopping) return;
        isStopping = true;
        Intent intent = new Intent(this, WorkoutService.class);
        intent.setAction(WorkoutService.ACTION_STOP);
        startService(intent);
        uiHandler.postDelayed(this::openSummaryOnce, 600);
    }

    private void openSummaryOnce() {
        if (summaryOpened) return;
        summaryOpened = true;
        uiHandler.removeCallbacks(uiTicker);
        Intent summary = new Intent(this, SummaryActivity.class);
        startActivity(summary);
        finish();
    }

    @Override
    protected void onDestroy() {
        uiHandler.removeCallbacks(uiTicker);
        super.onDestroy();
    }

    private String formatTime(long millis) {
        long totalSeconds = (millis + 999) / 1000;
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private void setupSystemBars() {
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.setStatusBarColor(Color.parseColor("#07111F"));
            window.setNavigationBarColor(Color.parseColor("#07111F"));
        }
    }

    private GradientDrawable makeRoundBg(String color, int radius, String strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.parseColor(color));
        drawable.setCornerRadius(radius);
        if (strokeColor != null) drawable.setStroke(strokeWidth, Color.parseColor(strokeColor));
        return drawable;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams matchWrapParams() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchHeightParams(int height) {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height);
    }
}
