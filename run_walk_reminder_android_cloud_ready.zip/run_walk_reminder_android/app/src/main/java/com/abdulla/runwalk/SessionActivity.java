package com.abdulla.runwalk;

import android.app.Activity;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class SessionActivity extends Activity {
    private TextView intervalText;
    private TextView timerText;
    private TextView stepText;
    private Button stopButton;
    private CountDownTimer countDownTimer;
    private List<Interval> intervals;
    private int currentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        int week = getIntent().getIntExtra("week", 1);
        intervals = getIntervalsForWeek(week);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(40, 40, 40, 40);

        TextView title = new TextView(this);
        title.setText("Week " + week + " Session");
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 30);
        root.addView(title);

        intervalText = new TextView(this);
        intervalText.setTextSize(42);
        intervalText.setGravity(Gravity.CENTER);
        intervalText.setPadding(0, 0, 0, 20);
        root.addView(intervalText);

        timerText = new TextView(this);
        timerText.setTextSize(56);
        timerText.setGravity(Gravity.CENTER);
        timerText.setPadding(0, 0, 0, 20);
        root.addView(timerText);

        stepText = new TextView(this);
        stepText.setTextSize(18);
        stepText.setGravity(Gravity.CENTER);
        stepText.setPadding(0, 0, 0, 40);
        root.addView(stepText);

        stopButton = new Button(this);
        stopButton.setText("Stop");
        stopButton.setTextSize(18);
        root.addView(stopButton);
        stopButton.setOnClickListener(v -> finish());

        setContentView(root);
        startCurrentInterval();
    }

    private void startCurrentInterval() {
        if (currentIndex >= intervals.size()) {
            playAlarm();
            Toast.makeText(this, "Finished. Good job!", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        Interval interval = intervals.get(currentIndex);
        intervalText.setText(interval.type);
        stepText.setText("Step " + (currentIndex + 1) + " of " + intervals.size());
        playAlarm();

        countDownTimer = new CountDownTimer(interval.durationMs, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timerText.setText(formatTime(millisUntilFinished));
            }

            @Override
            public void onFinish() {
                currentIndex++;
                startCurrentInterval();
            }
        };
        countDownTimer.start();
    }

    private String formatTime(long millis) {
        long totalSeconds = (millis + 999) / 1000;
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private void playAlarm() {
        try {
            ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
            tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500);
        } catch (Exception ignored) { }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) countDownTimer.cancel();
    }

    private List<Interval> getIntervalsForWeek(int week) {
        switch (week) {
            case 1: return repeat(8, 60, 90);
            case 2: return repeat(7, 90, 120);
            case 3: return repeat(6, 120, 120);
            case 4: return repeat(5, 180, 120);
            case 5: return repeat(4, 300, 120);
            case 6: return repeat(3, 480, 120);
            case 7: return repeat(3, 600, 120);
            case 8:
                List<Interval> list = new ArrayList<>();
                list.add(new Interval("JOG", 25 * 60 * 1000L));
                return list;
            default: return repeat(8, 60, 90);
        }
    }

    private List<Interval> repeat(int times, int jogSeconds, int walkSeconds) {
        List<Interval> list = new ArrayList<>();
        for (int i = 0; i < times; i++) {
            list.add(new Interval("JOG", jogSeconds * 1000L));
            list.add(new Interval("WALK", walkSeconds * 1000L));
        }
        return list;
    }

    private static class Interval {
        final String type;
        final long durationMs;
        Interval(String type, long durationMs) {
            this.type = type;
            this.durationMs = durationMs;
        }
    }
}
