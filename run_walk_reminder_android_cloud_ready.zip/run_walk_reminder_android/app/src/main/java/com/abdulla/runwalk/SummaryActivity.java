package com.abdulla.runwalk;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SummaryActivity extends Activity {
    private static final int REQUEST_BACKGROUND = 404;
    private static final String SUMMARY_PREFS = "runwalk_last_summary";

    private Uri selectedBackgroundUri;
    private ImageView previewBackground;
    private int week;
    private long dateMs;
    private long totalMs;
    private long jogMs;
    private long walkMs;
    private double calories;
    private boolean completed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupSystemBars();
        loadSummary();
        buildUi();
    }

    private void loadSummary() {
        SharedPreferences prefs = getSharedPreferences(SUMMARY_PREFS, MODE_PRIVATE);
        week = prefs.getInt("week", 1);
        dateMs = prefs.getLong("date_ms", System.currentTimeMillis());
        totalMs = prefs.getLong("total_ms", 0L);
        jogMs = prefs.getLong("jog_ms", 0L);
        walkMs = prefs.getLong("walk_ms", 0L);
        calories = prefs.getFloat("calories", 0f);
        completed = prefs.getBoolean("completed", true);
    }

    private void buildUi() {
        FrameLayout screen = new FrameLayout(this);

        previewBackground = new ImageView(this);
        previewBackground.setImageResource(R.drawable.bg_runwalk);
        previewBackground.setScaleType(ImageView.ScaleType.CENTER_CROP);
        screen.addView(previewBackground, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        View darkOverlay = new View(this);
        darkOverlay.setBackgroundColor(Color.parseColor("#B8000000"));
        screen.addView(darkOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22), dp(26), dp(22), dp(22));
        scrollView.addView(root);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.app_logo);
        logo.setAdjustViewBounds(true);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(90), dp(90));
        logoParams.setMargins(0, 0, 0, dp(12));
        root.addView(logo, logoParams);

        TextView title = new TextView(this);
        title.setText(completed ? "Workout Complete" : "Workout Summary");
        title.setTextColor(Color.WHITE);
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrapParams());

        TextView sub = new TextView(this);
        sub.setText("Week " + week + " • RunWalk");
        sub.setTextColor(Color.parseColor("#B7FBE0"));
        sub.setTextSize(17);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(4), 0, dp(18));
        root.addView(sub, matchWrapParams());

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(makeRoundBg("#D9111D2B", dp(26), "#3A5C78", dp(1)));
        LinearLayout.LayoutParams cardParams = matchWrapParams();
        cardParams.setMargins(0, dp(8), 0, dp(16));
        root.addView(card, cardParams);

        card.addView(makeStat("Total time", formatDuration(totalMs)), matchWrapParams());
        card.addView(makeStat("Jog time", formatDuration(jogMs)), matchWrapParams());
        card.addView(makeStat("Walk time", formatDuration(walkMs)), matchWrapParams());
        card.addView(makeStat("Calories", Math.round(calories) + " kcal"), matchWrapParams());

        TextView note = new TextView(this);
        note.setText("Calories are estimated");
        note.setTextColor(Color.parseColor("#9CAABD"));
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, dp(12), 0, 0);
        card.addView(note, matchWrapParams());

        Button chooseBg = makeButton("Choose Background from Phone", "#223248", Color.WHITE);
        root.addView(chooseBg, matchButtonParams());
        chooseBg.setOnClickListener(v -> chooseBackground());

        Button save = makeButton("Save as Image", "#00D084", Color.parseColor("#07111F"));
        root.addView(save, matchButtonParams());
        save.setOnClickListener(v -> saveSummaryImage());

        Button share = makeButton("Share Summary", "#FFB020", Color.parseColor("#07111F"));
        root.addView(share, matchButtonParams());
        share.setOnClickListener(v -> shareSummaryImage());

        Button done = makeButton("Done", "#D94040", Color.WHITE);
        root.addView(done, matchButtonParams());
        done.setOnClickListener(v -> finish());

        screen.addView(scrollView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        setContentView(screen);
    }

    private TextView makeStat(String label, String value) {
        TextView view = new TextView(this);
        view.setText(label + "\n" + value);
        view.setTextColor(Color.WHITE);
        view.setTextSize(21);
        view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable bg = makeRoundBg("#801A2B3A", dp(18), "#334C62", dp(1));
        view.setBackground(bg);
        LinearLayout.LayoutParams params = matchWrapParams();
        params.setMargins(0, dp(6), 0, dp(6));
        view.setLayoutParams(params);
        return view;
    }

    private Button makeButton(String text, String color, int textColor) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(16);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);
        button.setTextColor(textColor);
        button.setBackground(makeRoundBg(color, dp(20), null, 0));
        return button;
    }

    private void chooseBackground() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQUEST_BACKGROUND);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_BACKGROUND && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedBackgroundUri = data.getData();
            previewBackground.setImageURI(selectedBackgroundUri);
            previewBackground.setScaleType(ImageView.ScaleType.CENTER_CROP);
        }
    }

    private void saveSummaryImage() {
        try {
            Bitmap bitmap = createShareBitmap();
            Uri uri = saveBitmapToGallery(bitmap);
            if (uri != null) Toast.makeText(this, "Saved to gallery", Toast.LENGTH_LONG).show();
            else Toast.makeText(this, "Could not save image", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareSummaryImage() {
        try {
            Bitmap bitmap = createShareBitmap();
            Uri uri = saveBitmapToGallery(bitmap);
            if (uri == null) {
                Toast.makeText(this, "Could not create image", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("image/png");
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(shareIntent, "Share workout summary"));
        } catch (Exception e) {
            Toast.makeText(this, "Share failed", Toast.LENGTH_SHORT).show();
        }
    }

    private Bitmap createShareBitmap() throws Exception {
        int width = 1080;
        int height = 1920;
        Bitmap output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        Bitmap bg = loadBackgroundBitmap();
        drawCenterCrop(canvas, bg, width, height);

        Paint overlay = new Paint(Paint.ANTI_ALIAS_FLAG);
        overlay.setColor(Color.argb(165, 0, 0, 0));
        canvas.drawRect(0, 0, width, height, overlay);

        Bitmap logo = BitmapFactory.decodeResource(getResources(), R.drawable.app_logo);
        if (logo != null) {
            RectF logoRect = new RectF(390, 145, 690, 445);
            canvas.drawBitmap(logo, null, logoRect, null);
        }

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        paint.setColor(Color.WHITE);
        paint.setTextSize(78);
        canvas.drawText(completed ? "Workout Complete" : "Workout Summary", width / 2f, 555, paint);

        paint.setColor(Color.parseColor("#B7FBE0"));
        paint.setTextSize(42);
        canvas.drawText("Week " + week + " • RunWalk", width / 2f, 625, paint);

        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setColor(Color.parseColor("#D4DDE8"));
        paint.setTextSize(34);
        canvas.drawText(new SimpleDateFormat("dd MMM yyyy • HH:mm", Locale.getDefault()).format(new Date(dateMs)), width / 2f, 680, paint);

        Paint cardPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cardPaint.setColor(Color.argb(215, 13, 25, 39));
        RectF card = new RectF(90, 760, 990, 1435);
        canvas.drawRoundRect(card, 54, 54, cardPaint);

        drawStat(canvas, "Total Time", formatDuration(totalMs), 245, 900);
        drawStat(canvas, "Jog Time", formatDuration(jogMs), 835, 900);
        drawStat(canvas, "Walk Time", formatDuration(walkMs), 245, 1195);
        drawStat(canvas, "Calories", Math.round(calories) + " kcal", 835, 1195);

        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setColor(Color.WHITE);
        paint.setTextSize(44);
        canvas.drawText("Different days. Better fitness.", width / 2f, 1555, paint);

        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setColor(Color.parseColor("#B9C6D6"));
        paint.setTextSize(30);
        canvas.drawText("Calories are estimated", width / 2f, 1610, paint);

        paint.setColor(Color.parseColor("#B7FBE0"));
        paint.setTextSize(36);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText("RunWalk", width / 2f, 1745, paint);

        return output;
    }

    private void drawStat(Canvas canvas, String label, String value, int centerX, int centerY) {
        Paint tile = new Paint(Paint.ANTI_ALIAS_FLAG);
        tile.setColor(Color.argb(150, 18, 51, 35));
        RectF rect = new RectF(centerX - 210, centerY - 115, centerX + 210, centerY + 115);
        canvas.drawRoundRect(rect, 36, 36, tile);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setColor(Color.WHITE);
        paint.setTextSize(42);
        canvas.drawText(value, centerX, centerY - 10, paint);

        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setColor(Color.parseColor("#B7FBE0"));
        paint.setTextSize(28);
        canvas.drawText(label, centerX, centerY + 48, paint);
    }

    private Bitmap loadBackgroundBitmap() throws Exception {
        if (selectedBackgroundUri != null) {
            InputStream stream = getContentResolver().openInputStream(selectedBackgroundUri);
            Bitmap bitmap = BitmapFactory.decodeStream(stream);
            if (stream != null) stream.close();
            if (bitmap != null) return bitmap;
        }
        return BitmapFactory.decodeResource(getResources(), R.drawable.bg_runwalk);
    }

    private void drawCenterCrop(Canvas canvas, Bitmap bitmap, int targetW, int targetH) {
        if (bitmap == null) {
            canvas.drawColor(Color.parseColor("#07111F"));
            return;
        }
        float scale = Math.max(targetW / (float) bitmap.getWidth(), targetH / (float) bitmap.getHeight());
        float dx = (targetW - bitmap.getWidth() * scale) * 0.5f;
        float dy = (targetH - bitmap.getHeight() * scale) * 0.5f;
        Matrix matrix = new Matrix();
        matrix.setScale(scale, scale);
        matrix.postTranslate(dx, dy);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        canvas.drawBitmap(bitmap, matrix, paint);
    }

    private Uri saveBitmapToGallery(Bitmap bitmap) throws Exception {
        String name = "RunWalk_summary_" + System.currentTimeMillis() + ".png";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/RunWalk");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return null;
            OutputStream out = getContentResolver().openOutputStream(uri);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            if (out != null) out.close();
            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            getContentResolver().update(uri, values, null, null);
            return uri;
        } else {
            String saved = MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, name, "RunWalk workout summary");
            return saved == null ? null : Uri.parse(saved);
        }
    }

    private String formatDuration(long millis) {
        long seconds = Math.max(0, millis / 1000);
        long minutes = seconds / 60;
        long sec = seconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, sec);
    }

    private void setupSystemBars() {
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.setStatusBarColor(Color.parseColor("#07111F"));
            window.setNavigationBarColor(Color.parseColor("#07111F"));
        }
    }

    private GradientDrawable makeRoundBg(String color, int radius, String strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.parseColor(color));
        drawable.setCornerRadius(radius);
        if (strokeColor != null) drawable.setStroke(strokeWidth, Color.parseColor(strokeColor));
        return drawable;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams matchWrapParams() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchButtonParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        params.setMargins(0, dp(8), 0, 0);
        return params;
    }
}
