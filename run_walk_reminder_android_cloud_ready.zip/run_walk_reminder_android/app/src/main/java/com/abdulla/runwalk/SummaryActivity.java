package com.abdulla.runwalk;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Polyline;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class SummaryActivity extends Activity {
    private static final int REQUEST_BACKGROUND = 501;
    private static final String SUMMARY_PREFS = "runwalk_last_summary";

    private ImageView previewBackground;
    private Uri selectedBackgroundUri;
    private int week;
    private long dateMs;
    private long totalMs;
    private long jogMs;
    private long walkMs;
    private double calories;
    private double distanceMeters;
    private double paceSecondsPerKm;
    private double speedKmh;
    private boolean completed;
    private String trackRaw = "";
    private MapView mapView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupSystemBars();
        Configuration.getInstance().load(getApplicationContext(), getSharedPreferences("osmdroid", MODE_PRIVATE));
        Configuration.getInstance().setUserAgentValue(getPackageName());
        loadSummary();
        buildUi();
    }

    private void loadSummary() {
        SharedPreferences prefs = getSharedPreferences(SUMMARY_PREFS, MODE_PRIVATE);
        week = prefs.getInt("week", 1);
        dateMs = prefs.getLong("date_ms", System.currentTimeMillis());
        totalMs = prefs.getLong("total_ms", 0L);
        jogMs = prefs.getLong("jog_ms", 0L);
        walkMs = prefs.getLong("walk_ms", 0L);
        calories = prefs.getFloat("calories", 0f);
        distanceMeters = prefs.getFloat("distance_m", 0f);
        paceSecondsPerKm = prefs.getFloat("pace_sec_km", 0f);
        speedKmh = prefs.getFloat("speed_kmh", 0f);
        completed = prefs.getBoolean("completed", true);
        trackRaw = prefs.getString("track_points", "");
    }

    private void buildUi() {
        FrameLayout screen = new FrameLayout(this);
        previewBackground = new ImageView(this);
        previewBackground.setImageResource(R.drawable.bg_runwalk);
        previewBackground.setScaleType(ImageView.ScaleType.CENTER_CROP);
        screen.addView(previewBackground, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        View overlay = new View(this);
        overlay.setBackgroundColor(Color.parseColor("#B8000000"));
        screen.addView(overlay, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(24));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scrollView.addView(root);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.app_logo);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(92), dp(92));
        logoParams.setMargins(0, 0, 0, dp(10));
        root.addView(logo, logoParams);

        TextView title = new TextView(this);
        title.setText(completed ? "Workout Complete" : "Workout Summary");
        title.setTextColor(Color.WHITE);
        title.setTextSize(32);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrapParams());

        TextView date = new TextView(this);
        date.setText("Week " + week + " • " + new SimpleDateFormat("dd MMM yyyy • HH:mm", Locale.getDefault()).format(new Date(dateMs)));
        date.setTextColor(Color.parseColor("#B7FBE0"));
        date.setTextSize(15);
        date.setGravity(Gravity.CENTER);
        date.setPadding(0, dp(6), 0, dp(18));
        root.addView(date, matchWrapParams());

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(makeRoundBg("#CC0D1927", dp(26), "#2F4E6B", dp(1)));
        root.addView(card, matchWrapParams());

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(row1, matchWrapParams());
        row1.addView(makeStat("Total", formatDuration(totalMs)), weightedParams());
        row1.addView(makeStat("Calories", Math.round(calories) + " kcal"), weightedParams());

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(row2, matchWrapParams());
        row2.addView(makeStat("Distance", formatDistance(distanceMeters)), weightedParams());
        row2.addView(makeStat("Pace", formatPace(paceSecondsPerKm)), weightedParams());

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(row3, matchWrapParams());
        row3.addView(makeStat("Jog", formatDuration(jogMs)), weightedParams());
        row3.addView(makeStat("Walk", formatDuration(walkMs)), weightedParams());

        mapView = new MapView(this);
        mapView.setTileSource(TileSourceFactory.MAPNIK);
        mapView.setMultiTouchControls(true);
        mapView.getController().setZoom(16.0);
        mapView.setBackgroundColor(Color.parseColor("#0B1728"));
        LinearLayout.LayoutParams mapParams = matchHeightParams(dp(230));
        mapParams.setMargins(0, dp(14), 0, dp(8));
        card.addView(mapView, mapParams);
        drawRouteOnMap();

        TextView note = new TextView(this);
        note.setText("Calories and GPS distance are estimates");
        note.setTextColor(Color.parseColor("#B9C6D6"));
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, dp(10), 0, 0);
        card.addView(note, matchWrapParams());

        Button chooseBg = makeButton("Choose Background from Phone", "#223248", Color.WHITE);
        root.addView(chooseBg, matchButtonParams());
        chooseBg.setOnClickListener(v -> chooseBackground());

        Button save = makeButton("Save as Image", "#00D084", Color.parseColor("#07111F"));
        root.addView(save, matchButtonParams());
        save.setOnClickListener(v -> saveSummaryImage());

        Button share = makeButton("Share Summary", "#FFB020", Color.parseColor("#07111F"));
        root.addView(share, matchButtonParams());
        share.setOnClickListener(v -> shareSummaryImage());

        Button history = makeButton("History / Progress", "#223248", Color.WHITE);
        root.addView(history, matchButtonParams());
        history.setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));

        Button done = makeButton("Done", "#D94040", Color.WHITE);
        root.addView(done, matchButtonParams());
        done.setOnClickListener(v -> finish());

        screen.addView(scrollView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(screen);
    }

    private TextView makeStat(String label, String value) {
        TextView view = new TextView(this);
        view.setText(label + "\n" + value);
        view.setTextColor(Color.WHITE);
        view.setTextSize(17);
        view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(8), dp(12), dp(8), dp(12));
        view.setBackground(makeRoundBg("#801A2B3A", dp(18), "#334C62", dp(1)));
        return view;
    }

    private Button makeButton(String text, String color, int textColor) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(16);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);
        button.setTextColor(textColor);
        button.setBackground(makeRoundBg(color, dp(20), null, 0));
        return button;
    }

    private void drawRouteOnMap() {
        if (mapView == null) return;
        List<GeoPoint> route = parseTrackGeoPoints();
        if (route.isEmpty()) return;
        Polyline line = new Polyline(mapView);
        line.setColor(Color.parseColor("#00D084"));
        line.setWidth(dp(5));
        line.setPoints(route);
        mapView.getOverlays().add(line);
        mapView.getController().setCenter(route.get(route.size() - 1));
        mapView.invalidate();
    }

    private List<GeoPoint> parseTrackGeoPoints() {
        List<GeoPoint> list = new ArrayList<>();
        if (trackRaw == null || trackRaw.trim().isEmpty()) return list;
        String[] points = trackRaw.split("\\|");
        for (String point : points) {
            String[] parts = point.split(",");
            if (parts.length != 2) continue;
            try {
                list.add(new GeoPoint(Double.parseDouble(parts[0]), Double.parseDouble(parts[1])));
            } catch (Exception ignored) { }
        }
        return list;
    }

    private void chooseBackground() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQUEST_BACKGROUND);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_BACKGROUND && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedBackgroundUri = data.getData();
            previewBackground.setImageURI(selectedBackgroundUri);
            previewBackground.setScaleType(ImageView.ScaleType.CENTER_CROP);
        }
    }

    private void saveSummaryImage() {
        try {
            Uri uri = saveBitmapToGallery(createShareBitmap());
            Toast.makeText(this, uri != null ? "Saved to gallery" : "Could not save image", Toast.LENGTH_LONG).show();
        } catch (Exception e) { Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show(); }
    }

    private void shareSummaryImage() {
        try {
            Uri uri = saveBitmapToGallery(createShareBitmap());
            if (uri == null) { Toast.makeText(this, "Could not create image", Toast.LENGTH_SHORT).show(); return; }
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("image/png");
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(shareIntent, "Share workout summary"));
        } catch (Exception e) { Toast.makeText(this, "Share failed", Toast.LENGTH_SHORT).show(); }
    }

    private Bitmap createShareBitmap() throws Exception {
        int width = 1080;
        int height = 1920;
        Bitmap output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        Bitmap bg = loadBackgroundBitmap();
        drawCenterCrop(canvas, bg, width, height);

        Paint overlay = new Paint(Paint.ANTI_ALIAS_FLAG);
        overlay.setColor(Color.argb(170, 0, 0, 0));
        canvas.drawRect(0, 0, width, height, overlay);

        Bitmap logo = BitmapFactory.decodeResource(getResources(), R.drawable.app_logo);
        if (logo != null) canvas.drawBitmap(logo, null, new RectF(390, 110, 690, 410), null);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setColor(Color.WHITE);
        paint.setTextSize(76);
        canvas.drawText(completed ? "Workout Complete" : "Workout Summary", width / 2f, 520, paint);

        paint.setColor(Color.parseColor("#B7FBE0"));
        paint.setTextSize(42);
        canvas.drawText("Week " + week + " • RunWalk", width / 2f, 590, paint);

        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setColor(Color.parseColor("#D4DDE8"));
        paint.setTextSize(34);
        canvas.drawText(new SimpleDateFormat("dd MMM yyyy • HH:mm", Locale.getDefault()).format(new Date(dateMs)), width / 2f, 645, paint);

        Paint cardPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cardPaint.setColor(Color.argb(220, 13, 25, 39));
        RectF card = new RectF(70, 720, 1010, 1515);
        canvas.drawRoundRect(card, 54, 54, cardPaint);

        drawStat(canvas, "Total Time", formatDuration(totalMs), 245, 850);
        drawStat(canvas, "Calories", Math.round(calories) + " kcal", 835, 850);
        drawStat(canvas, "Distance", formatDistance(distanceMeters), 245, 1115);
        drawStat(canvas, "Pace", formatPace(paceSecondsPerKm), 835, 1115);
        drawMiniRoute(canvas, new RectF(150, 1270, 930, 1455));

        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setColor(Color.WHITE);
        paint.setTextSize(44);
        canvas.drawText("Different days. Better fitness.", width / 2f, 1610, paint);

        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setColor(Color.parseColor("#B9C6D6"));
        paint.setTextSize(30);
        canvas.drawText("Calories and GPS distance are estimated", width / 2f, 1665, paint);

        paint.setColor(Color.parseColor("#B7FBE0"));
        paint.setTextSize(36);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText("RunWalk", width / 2f, 1795, paint);
        return output;
    }

    private void drawMiniRoute(Canvas canvas, RectF rect) {
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(Color.argb(150, 10, 22, 36));
        canvas.drawRoundRect(rect, 36, 36, bg);

        List<GeoPoint> route = parseTrackGeoPoints();
        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        textPaint.setColor(Color.parseColor("#B7FBE0"));
        textPaint.setTextSize(30);
        if (route.size() < 2) {
            canvas.drawText("Route preview appears after GPS tracking", rect.centerX(), rect.centerY() + 10, textPaint);
            return;
        }
        double minLat = route.get(0).getLatitude(), maxLat = minLat, minLon = route.get(0).getLongitude(), maxLon = minLon;
        for (GeoPoint p : route) {
            minLat = Math.min(minLat, p.getLatitude()); maxLat = Math.max(maxLat, p.getLatitude());
            minLon = Math.min(minLon, p.getLongitude()); maxLon = Math.max(maxLon, p.getLongitude());
        }
        double latRange = Math.max(0.00001, maxLat - minLat);
        double lonRange = Math.max(0.00001, maxLon - minLon);
        Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        linePaint.setColor(Color.parseColor("#00D084"));
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeCap(Paint.Cap.ROUND);
        linePaint.setStrokeJoin(Paint.Join.ROUND);
        linePaint.setStrokeWidth(12f);
        float prevX = 0, prevY = 0;
        boolean first = true;
        for (GeoPoint p : route) {
            float x = (float) (rect.left + 40 + ((p.getLongitude() - minLon) / lonRange) * (rect.width() - 80));
            float y = (float) (rect.bottom - 35 - ((p.getLatitude() - minLat) / latRange) * (rect.height() - 70));
            if (!first) canvas.drawLine(prevX, prevY, x, y, linePaint);
            prevX = x; prevY = y; first = false;
        }
        canvas.drawText("Route", rect.centerX(), rect.top + 38, textPaint);
    }

    private void drawStat(Canvas canvas, String label, String value, int centerX, int centerY) {
        Paint tile = new Paint(Paint.ANTI_ALIAS_FLAG);
        tile.setColor(Color.argb(150, 18, 51, 35));
        RectF rect = new RectF(centerX - 210, centerY - 105, centerX + 210, centerY + 105);
        canvas.drawRoundRect(rect, 34, 34, tile);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setColor(Color.WHITE);
        paint.setTextSize(40);
        canvas.drawText(value, centerX, centerY - 6, paint);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setColor(Color.parseColor("#B7FBE0"));
        paint.setTextSize(27);
        canvas.drawText(label, centerX, centerY + 48, paint);
    }

    private Bitmap loadBackgroundBitmap() throws Exception {
        if (selectedBackgroundUri != null) {
            InputStream stream = getContentResolver().openInputStream(selectedBackgroundUri);
            Bitmap bitmap = BitmapFactory.decodeStream(stream);
            if (stream != null) stream.close();
            if (bitmap != null) return bitmap;
        }
        return BitmapFactory.decodeResource(getResources(), R.drawable.bg_runwalk);
    }

    private void drawCenterCrop(Canvas canvas, Bitmap bitmap, int targetW, int targetH) {
        if (bitmap == null) { canvas.drawColor(Color.parseColor("#07111F")); return; }
        float scale = Math.max(targetW / (float) bitmap.getWidth(), targetH / (float) bitmap.getHeight());
        float dx = (targetW - bitmap.getWidth() * scale) * 0.5f;
        float dy = (targetH - bitmap.getHeight() * scale) * 0.5f;
        Matrix matrix = new Matrix();
        matrix.setScale(scale, scale);
        matrix.postTranslate(dx, dy);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        canvas.drawBitmap(bitmap, matrix, paint);
    }

    private Uri saveBitmapToGallery(Bitmap bitmap) throws Exception {
        String name = "RunWalk_summary_" + System.currentTimeMillis() + ".png";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/RunWalk");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return null;
            OutputStream out = getContentResolver().openOutputStream(uri);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            if (out != null) out.close();
            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            getContentResolver().update(uri, values, null, null);
            return uri;
        } else {
            String saved = MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, name, "RunWalk workout summary");
            return saved == null ? null : Uri.parse(saved);
        }
    }

    @Override protected void onResume() { super.onResume(); if (mapView != null) mapView.onResume(); }
    @Override protected void onPause() { if (mapView != null) mapView.onPause(); super.onPause(); }
    @Override protected void onDestroy() { if (mapView != null) mapView.onDetach(); super.onDestroy(); }

    private String formatDuration(long millis) {
        long seconds = Math.max(0, millis / 1000);
        long minutes = seconds / 60;
        long sec = seconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, sec);
    }

    private String formatDistance(double meters) {
        if (meters >= 1000) return String.format(Locale.getDefault(), "%.2f km", meters / 1000.0);
        return Math.round(meters) + " m";
    }

    private String formatPace(double secondsPerKm) {
        if (secondsPerKm <= 0) return "--";
        long sec = Math.round(secondsPerKm);
        return String.format(Locale.getDefault(), "%d:%02d/km", sec / 60, sec % 60);
    }

    private void setupSystemBars() {
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.setStatusBarColor(Color.parseColor("#07111F"));
            window.setNavigationBarColor(Color.parseColor("#07111F"));
        }
    }

    private GradientDrawable makeRoundBg(String color, int radius, String strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.parseColor(color));
        drawable.setCornerRadius(radius);
        if (strokeColor != null) drawable.setStroke(strokeWidth, Color.parseColor(strokeColor));
        return drawable;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout.LayoutParams matchWrapParams() { return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams matchHeightParams(int height) { return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height); }
    private LinearLayout.LayoutParams matchButtonParams() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54)); p.setMargins(0, dp(8), 0, 0); return p; }
    private LinearLayout.LayoutParams weightedParams() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1); p.setMargins(dp(4), dp(4), dp(4), dp(4)); return p; }
}
