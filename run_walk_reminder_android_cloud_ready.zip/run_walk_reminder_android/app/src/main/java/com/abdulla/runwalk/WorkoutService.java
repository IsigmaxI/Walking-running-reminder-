package com.abdulla.runwalk;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.List;

public class WorkoutService extends Service {
    public static final String ACTION_START = "com.abdulla.runwalk.START_WORKOUT";
    public static final String ACTION_STOP = "com.abdulla.runwalk.STOP_WORKOUT";

    private static final String PREFS = "runwalk_profile";
    private static final String SUMMARY_PREFS = "runwalk_last_summary";
    private static final String CHANNEL_ID = "runwalk_workout_channel";
    private static final int NOTIFICATION_ID = 2001;

    private static Snapshot latestSnapshot;
    private static boolean serviceRunning = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            tickWorkout();
            if (serviceRunning && !finished) {
                handler.postDelayed(this, 500);
            }
        }
    };

    private List<Interval> intervals = new ArrayList<>();
    private int week = 1;
    private int currentIndex = 0;
    private long intervalStartMs = 0L;
    private long workoutStartEpochMs = 0L;
    private long completedJogMs = 0L;
    private long completedWalkMs = 0L;
    private double completedCalories = 0.0;
    private double bmr = 1800.0;
    private boolean finished = false;
    private boolean completed = false;
    private PowerManager.WakeLock wakeLock;

    public static boolean isRunning() {
        return serviceRunning && latestSnapshot != null && !latestSnapshot.finished;
    }

    public static Snapshot getSnapshot() {
        return latestSnapshot;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_STOP.equals(action)) {
            finishWorkout(false);
            return START_NOT_STICKY;
        }

        if (ACTION_START.equals(action)) {
            int requestedWeek = intent.getIntExtra("week", 1);
            if (!serviceRunning || finished) {
                startWorkout(requestedWeek);
            }
        }
        return START_STICKY;
    }

    private void startWorkout(int requestedWeek) {
        week = requestedWeek;
        intervals = getIntervalsForWeek(week);
        currentIndex = 0;
        completedJogMs = 0L;
        completedWalkMs = 0L;
        completedCalories = 0.0;
        workoutStartEpochMs = System.currentTimeMillis();
        intervalStartMs = SystemClock.elapsedRealtime();
        finished = false;
        completed = false;
        serviceRunning = true;
        loadProfileForCalories();
        acquireWakeLock();
        latestSnapshot = buildSnapshot();
        Notification workoutNotification = buildNotification("Workout running", "RunWalk is keeping your interval timer active.");
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, workoutNotification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, workoutNotification);
        }
        playAlarm();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    private void tickWorkout() {
        if (finished || intervals.isEmpty()) return;

        long now = SystemClock.elapsedRealtime();
        Interval interval = intervals.get(currentIndex);
        long elapsed = now - intervalStartMs;

        while (elapsed >= interval.durationMs && !finished) {
            completedCalories += calculateCalories(interval.type, interval.durationMs);
            if ("JOG".equals(interval.type)) completedJogMs += interval.durationMs;
            else completedWalkMs += interval.durationMs;

            currentIndex++;
            if (currentIndex >= intervals.size()) {
                finishWorkout(true);
                return;
            }

            intervalStartMs = now - (elapsed - interval.durationMs);
            interval = intervals.get(currentIndex);
            elapsed = now - intervalStartMs;
            playAlarm();
        }

        latestSnapshot = buildSnapshot();
        updateNotification();
    }

    private void finishWorkout(boolean isCompleted) {
        if (finished) return;
        finished = true;
        completed = isCompleted;

        if (intervals != null && currentIndex < intervals.size()) {
            long now = SystemClock.elapsedRealtime();
            Interval interval = intervals.get(currentIndex);
            long elapsed = Math.max(0, Math.min(interval.durationMs, now - intervalStartMs));
            if (elapsed > 0) {
                if ("JOG".equals(interval.type)) completedJogMs += elapsed;
                else completedWalkMs += elapsed;
            }
        }

        double totalCalories = getCurrentTotalCalories();
        long totalMs = completedJogMs + completedWalkMs;
        saveSummary(totalMs, completedJogMs, completedWalkMs, totalCalories, isCompleted);
        latestSnapshot = new Snapshot(
                week,
                true,
                isCompleted,
                "DONE",
                0L,
                currentIndex,
                intervals == null ? 0 : intervals.size(),
                totalMs,
                completedJogMs,
                completedWalkMs,
                totalCalories
        );

        playAlarm();
        stopForeground(false);
        Notification doneNotification = buildNotification(isCompleted ? "Workout complete" : "Workout stopped", Math.round(totalCalories) + " kcal • Tap to view summary");
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, doneNotification);
        handler.removeCallbacks(ticker);
        releaseWakeLock();
        serviceRunning = false;
        stopSelf();
    }

    private Snapshot buildSnapshot() {
        if (intervals == null || intervals.isEmpty()) {
            return new Snapshot(week, true, false, "DONE", 0, 0, 0, 0, 0, 0, 0);
        }
        if (currentIndex >= intervals.size()) {
            return new Snapshot(week, true, completed, "DONE", 0, intervals.size(), intervals.size(), completedJogMs + completedWalkMs, completedJogMs, completedWalkMs, completedCalories);
        }
        Interval interval = intervals.get(currentIndex);
        long elapsed = Math.max(0, SystemClock.elapsedRealtime() - intervalStartMs);
        long remaining = Math.max(0, interval.durationMs - elapsed);
        long jogMs = completedJogMs + ("JOG".equals(interval.type) ? Math.min(elapsed, interval.durationMs) : 0);
        long walkMs = completedWalkMs + ("WALK".equals(interval.type) ? Math.min(elapsed, interval.durationMs) : 0);
        double calories = completedCalories + calculateCalories(interval.type, Math.min(elapsed, interval.durationMs));
        return new Snapshot(
                week,
                false,
                false,
                interval.type,
                remaining,
                currentIndex + 1,
                intervals.size(),
                jogMs + walkMs,
                jogMs,
                walkMs,
                calories
        );
    }

    private void saveSummary(long totalMs, long jogMs, long walkMs, double calories, boolean isCompleted) {
        getSharedPreferences(SUMMARY_PREFS, MODE_PRIVATE).edit()
                .putInt("week", week)
                .putLong("date_ms", System.currentTimeMillis())
                .putLong("total_ms", totalMs)
                .putLong("jog_ms", jogMs)
                .putLong("walk_ms", walkMs)
                .putFloat("calories", (float) calories)
                .putBoolean("completed", isCompleted)
                .apply();
    }

    private double getCurrentTotalCalories() {
        if (intervals == null || currentIndex >= intervals.size()) return completedCalories;
        long elapsed = Math.max(0, Math.min(intervals.get(currentIndex).durationMs, SystemClock.elapsedRealtime() - intervalStartMs));
        return completedCalories + calculateCalories(intervals.get(currentIndex).type, elapsed);
    }

    private double calculateCalories(String type, long elapsedMs) {
        double minutes = elapsedMs / 60000.0;
        double met = "JOG".equals(type) ? 7.0 : 3.5;
        return (bmr / 1440.0) * met * minutes;
    }

    private void loadProfileForCalories() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        float weight = prefs.getFloat("weight_kg", 80f);
        int age = prefs.getInt("age", 30);
        int height = prefs.getInt("height_cm", 170);
        String gender = prefs.getString("gender", "Male");
        if ("Female".equals(gender)) {
            bmr = 10.0 * weight + 6.25 * height - 5.0 * age - 161.0;
        } else {
            bmr = 10.0 * weight + 6.25 * height - 5.0 * age + 5.0;
        }
        if (bmr < 900) bmr = 900;
    }

    private void acquireWakeLock() {
        try {
            PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (powerManager != null) {
                wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RunWalk:WorkoutTimer");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(3 * 60 * 60 * 1000L);
            }
        } catch (Exception ignored) { }
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) { }
    }

    private Notification buildNotification(String title, String text) {
        Intent openIntent;
        if (finished) {
            openIntent = new Intent(this, SummaryActivity.class);
        } else {
            openIntent = new Intent(this, SessionActivity.class);
            openIntent.putExtra("week", week);
        }
        openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 99, openIntent, flags);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        builder.setSmallIcon(R.drawable.ic_runwalk_icon)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pendingIntent)
                .setOngoing(!finished)
                .setOnlyAlertOnce(true)
                .setColor(Color.parseColor("#00D084"));

        if (Build.VERSION.SDK_INT >= 21) builder.setVisibility(Notification.VISIBILITY_PUBLIC);
        return builder.build();
    }

    private void updateNotification() {
        Snapshot s = latestSnapshot;
        if (s == null || s.finished) return;
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            String line = ("JOG".equals(s.intervalType) ? "Jog" : "Walk") + " • " + formatTime(s.remainingMs) + " • " + Math.round(s.calories) + " kcal";
            manager.notify(NOTIFICATION_ID, buildNotification("RunWalk is active", line));
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "RunWalk workout", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps workout timer running when the screen is locked.");
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void playAlarm() {
        try {
            ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
            tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500);
            handler.postDelayed(tone::release, 800);
        } catch (Exception ignored) { }
    }

    private String formatTime(long millis) {
        long totalSeconds = (millis + 999) / 1000;
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private List<Interval> getIntervalsForWeek(int week) {
        switch (week) {
            case 1: return repeat(8, 60, 90);
            case 2: return repeat(7, 90, 120);
            case 3: return repeat(6, 120, 120);
            case 4: return repeat(5, 180, 120);
            case 5: return repeat(4, 300, 120);
            case 6: return repeat(3, 480, 120);
            case 7: return repeat(3, 600, 120);
            case 8:
                List<Interval> list = new ArrayList<>();
                list.add(new Interval("JOG", 25 * 60 * 1000L));
                return list;
            default: return repeat(8, 60, 90);
        }
    }

    private List<Interval> repeat(int times, int jogSeconds, int walkSeconds) {
        List<Interval> list = new ArrayList<>();
        for (int i = 0; i < times; i++) {
            list.add(new Interval("JOG", jogSeconds * 1000L));
            list.add(new Interval("WALK", walkSeconds * 1000L));
        }
        return list;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(ticker);
        releaseWakeLock();
        super.onDestroy();
    }

    private static class Interval {
        final String type;
        final long durationMs;
        Interval(String type, long durationMs) {
            this.type = type;
            this.durationMs = durationMs;
        }
    }

    public static class Snapshot {
        public final int week;
        public final boolean finished;
        public final boolean completed;
        public final String intervalType;
        public final long remainingMs;
        public final int step;
        public final int totalSteps;
        public final long totalMs;
        public final long jogMs;
        public final long walkMs;
        public final double calories;

        Snapshot(int week, boolean finished, boolean completed, String intervalType, long remainingMs, int step, int totalSteps, long totalMs, long jogMs, long walkMs, double calories) {
            this.week = week;
            this.finished = finished;
            this.completed = completed;
            this.intervalType = intervalType;
            this.remainingMs = remainingMs;
            this.step = step;
            this.totalSteps = totalSteps;
            this.totalMs = totalMs;
            this.jogMs = jogMs;
            this.walkMs = walkMs;
            this.calories = calories;
        }
    }
}
