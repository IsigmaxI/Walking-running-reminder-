package com.abdulla.runwalk;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.graphics.Color;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class WorkoutService extends Service {
    public static final String ACTION_START = "com.abdulla.runwalk.START_WORKOUT";
    public static final String ACTION_STOP = "com.abdulla.runwalk.STOP_WORKOUT";
    public static final String ACTION_PAUSE = "com.abdulla.runwalk.PAUSE_WORKOUT";
    public static final String ACTION_RESUME = "com.abdulla.runwalk.RESUME_WORKOUT";

    private static final String PREFS = "runwalk_profile";
    private static final String SUMMARY_PREFS = "runwalk_last_summary";
    private static final String CHANNEL_ID = "runwalk_workout_channel";
    private static final int NOTIFICATION_ID = 2001;

    private static Snapshot latestSnapshot;
    private static boolean serviceRunning = false;
    private static final List<RoutePoint> routePoints = new ArrayList<>();

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            tickWorkout();
            if (serviceRunning && !finished) handler.postDelayed(this, 500);
        }
    };

    private final LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            handleLocation(location);
        }

        @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
        @Override public void onProviderEnabled(String provider) { }
        @Override public void onProviderDisabled(String provider) { }
    };

    private List<Interval> intervals = new ArrayList<>();
    private int week = 1;
    private int currentIndex = 0;
    private long intervalStartMs = 0L;
    private long pauseStartMs = 0L;
    private long completedJogMs = 0L;
    private long completedWalkMs = 0L;
    private double completedCalories = 0.0;
    private double bmr = 1800.0;
    private boolean finished = false;
    private boolean completed = false;
    private boolean paused = false;
    private PowerManager.WakeLock wakeLock;
    private TextToSpeech textToSpeech;
    private boolean textToSpeechReady = false;
    private String pendingSpeechType = null;

    private LocationManager locationManager;
    private Location lastLocation;
    private double totalDistanceMeters = 0.0;
    private double currentSpeedKmh = 0.0;
    private int lastCountdownSecond = -1;

    public static boolean isRunning() {
        return serviceRunning && latestSnapshot != null && !latestSnapshot.finished;
    }

    public static Snapshot getSnapshot() {
        return latestSnapshot;
    }

    public static List<RoutePoint> getTrackPoints() {
        synchronized (routePoints) {
            return new ArrayList<>(routePoints);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        initTextToSpeech();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_STOP.equals(action)) {
            finishWorkout(false);
            return START_NOT_STICKY;
        }
        if (ACTION_PAUSE.equals(action)) {
            pauseWorkout();
            return START_STICKY;
        }
        if (ACTION_RESUME.equals(action)) {
            resumeWorkout();
            return START_STICKY;
        }
        if (ACTION_START.equals(action)) {
            int requestedWeek = intent.getIntExtra("week", 1);
            if (!serviceRunning || finished) startWorkout(requestedWeek);
        }
        return START_STICKY;
    }

    private void startWorkout(int requestedWeek) {
        week = requestedWeek;
        intervals = getIntervalsForWeek(week);
        currentIndex = 0;
        completedJogMs = 0L;
        completedWalkMs = 0L;
        completedCalories = 0.0;
        totalDistanceMeters = 0.0;
        currentSpeedKmh = 0.0;
        lastLocation = null;
        lastCountdownSecond = -1;
        intervalStartMs = SystemClock.elapsedRealtime();
        pauseStartMs = 0L;
        finished = false;
        completed = false;
        paused = false;
        serviceRunning = true;
        synchronized (routePoints) { routePoints.clear(); }
        loadProfileForCalories();
        acquireWakeLock();
        latestSnapshot = buildSnapshot();

        Notification workoutNotification = buildNotification("Workout running", "RunWalk is tracking your workout.");
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                int type = hasLocationPermission() ? ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION : ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
                startForeground(NOTIFICATION_ID, workoutNotification, type);
            } else {
                startForeground(NOTIFICATION_ID, workoutNotification);
            }
        } catch (Exception e) {
            startForeground(NOTIFICATION_ID, workoutNotification);
        }

        startLocationTrackingIfAllowed();
        playIntervalCue(intervals.isEmpty() ? "JOG" : intervals.get(0).type);
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    private void pauseWorkout() {
        if (!serviceRunning || finished || paused) return;
        paused = true;
        pauseStartMs = SystemClock.elapsedRealtime();
        latestSnapshot = buildSnapshot();
        updateNotification();
        vibrate(120);
    }

    private void resumeWorkout() {
        if (!serviceRunning || finished || !paused) return;
        long now = SystemClock.elapsedRealtime();
        intervalStartMs += now - pauseStartMs;
        paused = false;
        pauseStartMs = 0L;
        lastCountdownSecond = -1;
        latestSnapshot = buildSnapshot();
        playIntervalCue(intervals.get(currentIndex).type);
        handler.removeCallbacks(ticker);
        handler.post(ticker);
        updateNotification();
    }

    private void tickWorkout() {
        if (finished || intervals.isEmpty()) return;
        if (paused) {
            latestSnapshot = buildSnapshot();
            updateNotification();
            return;
        }

        long now = SystemClock.elapsedRealtime();
        Interval interval = intervals.get(currentIndex);
        long elapsed = now - intervalStartMs;

        while (elapsed >= interval.durationMs && !finished) {
            completedCalories += calculateCalories(interval.type, interval.durationMs);
            if ("JOG".equals(interval.type)) completedJogMs += interval.durationMs;
            else completedWalkMs += interval.durationMs;

            currentIndex++;
            if (currentIndex >= intervals.size()) {
                finishWorkout(true);
                return;
            }

            intervalStartMs = now - (elapsed - interval.durationMs);
            interval = intervals.get(currentIndex);
            elapsed = now - intervalStartMs;
            lastCountdownSecond = -1;
            playIntervalCue(interval.type);
        }

        long remaining = Math.max(0, interval.durationMs - elapsed);
        int countdown = (int) ((remaining + 999) / 1000);
        if (countdown >= 1 && countdown <= 5 && countdown != lastCountdownSecond) {
            lastCountdownSecond = countdown;
            playCountdownBeep();
        }

        latestSnapshot = buildSnapshot();
        updateNotification();
    }

    private void finishWorkout(boolean isCompleted) {
        if (finished) return;
        finished = true;
        completed = isCompleted;

        if (intervals != null && currentIndex < intervals.size()) {
            Interval interval = intervals.get(currentIndex);
            long elapsed = Math.max(0, Math.min(interval.durationMs, currentIntervalElapsedMs()));
            if (elapsed > 0) {
                if ("JOG".equals(interval.type)) completedJogMs += elapsed;
                else completedWalkMs += elapsed;
            }
        }

        double totalCalories = getCurrentTotalCalories();
        long totalMs = completedJogMs + completedWalkMs;
        saveSummary(totalMs, completedJogMs, completedWalkMs, totalCalories, isCompleted);
        latestSnapshot = new Snapshot(
                week, true, isCompleted, false, "DONE", 0L, 0,
                currentIndex, intervals == null ? 0 : intervals.size(),
                totalMs, completedJogMs, completedWalkMs, totalCalories,
                totalDistanceMeters, currentSpeedKmh, calculatePaceSecondsPerKm(totalMs, totalDistanceMeters)
        );

        playFinishedCue();
        stopLocationTracking();
        stopForeground(false);
        Notification doneNotification = buildNotification(isCompleted ? "Workout complete" : "Workout stopped", Math.round(totalCalories) + " kcal • " + formatDistance(totalDistanceMeters) + " • Tap to view summary");
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, doneNotification);
        handler.removeCallbacks(ticker);
        releaseWakeLock();
        serviceRunning = false;
        stopSelf();
    }

    private Snapshot buildSnapshot() {
        if (intervals == null || intervals.isEmpty()) {
            return new Snapshot(week, true, false, false, "DONE", 0, 0, 0, 0, 0, 0, 0, 0, totalDistanceMeters, currentSpeedKmh, 0);
        }
        if (currentIndex >= intervals.size()) {
            long totalMs = completedJogMs + completedWalkMs;
            return new Snapshot(week, true, completed, false, "DONE", 0, 0, intervals.size(), intervals.size(), totalMs, completedJogMs, completedWalkMs, completedCalories, totalDistanceMeters, currentSpeedKmh, calculatePaceSecondsPerKm(totalMs, totalDistanceMeters));
        }
        Interval interval = intervals.get(currentIndex);
        long elapsed = Math.max(0, currentIntervalElapsedMs());
        elapsed = Math.min(elapsed, interval.durationMs);
        long remaining = Math.max(0, interval.durationMs - elapsed);
        int countdown = remaining <= 5000 ? (int) ((remaining + 999) / 1000) : 0;
        long jogMs = completedJogMs + ("JOG".equals(interval.type) ? elapsed : 0);
        long walkMs = completedWalkMs + ("WALK".equals(interval.type) ? elapsed : 0);
        double calories = completedCalories + calculateCalories(interval.type, elapsed);
        long totalMs = jogMs + walkMs;
        return new Snapshot(
                week,
                false,
                false,
                paused,
                interval.type,
                remaining,
                countdown,
                currentIndex + 1,
                intervals.size(),
                totalMs,
                jogMs,
                walkMs,
                calories,
                totalDistanceMeters,
                currentSpeedKmh,
                calculatePaceSecondsPerKm(totalMs, totalDistanceMeters)
        );
    }

    private long currentIntervalElapsedMs() {
        long now = paused ? pauseStartMs : SystemClock.elapsedRealtime();
        return now - intervalStartMs;
    }

    private void saveSummary(long totalMs, long jogMs, long walkMs, double calories, boolean isCompleted) {
        String track = encodeRoutePoints();
        getSharedPreferences(SUMMARY_PREFS, MODE_PRIVATE).edit()
                .putInt("week", week)
                .putLong("date_ms", System.currentTimeMillis())
                .putLong("total_ms", totalMs)
                .putLong("jog_ms", jogMs)
                .putLong("walk_ms", walkMs)
                .putFloat("calories", (float) calories)
                .putBoolean("completed", isCompleted)
                .putFloat("distance_m", (float) totalDistanceMeters)
                .putFloat("speed_kmh", (float) currentSpeedKmh)
                .putFloat("pace_sec_km", (float) calculatePaceSecondsPerKm(totalMs, totalDistanceMeters))
                .putString("track_points", track)
                .apply();

        WorkoutHistory.Entry entry = new WorkoutHistory.Entry();
        entry.dateMs = System.currentTimeMillis();
        entry.week = week;
        entry.totalMs = totalMs;
        entry.jogMs = jogMs;
        entry.walkMs = walkMs;
        entry.calories = calories;
        entry.distanceMeters = totalDistanceMeters;
        entry.completed = isCompleted;
        WorkoutHistory.add(this, entry);
    }

    private double getCurrentTotalCalories() {
        if (intervals == null || currentIndex >= intervals.size()) return completedCalories;
        long elapsed = Math.max(0, Math.min(intervals.get(currentIndex).durationMs, currentIntervalElapsedMs()));
        return completedCalories + calculateCalories(intervals.get(currentIndex).type, elapsed);
    }

    private double calculateCalories(String type, long elapsedMs) {
        double minutes = elapsedMs / 60000.0;
        double met = "JOG".equals(type) ? 7.0 : 3.5;
        return (bmr / 1440.0) * met * minutes;
    }

    private void loadProfileForCalories() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        float weight = prefs.getFloat("weight_kg", 80f);
        int age = prefs.getInt("age", 30);
        int height = prefs.getInt("height_cm", 170);
        String gender = prefs.getString("gender", "Male");
        if ("Female".equals(gender)) bmr = 10.0 * weight + 6.25 * height - 5.0 * age - 161.0;
        else bmr = 10.0 * weight + 6.25 * height - 5.0 * age + 5.0;
        if (bmr < 900) bmr = 900;
    }

    private void startLocationTrackingIfAllowed() {
        if (!hasLocationPermission()) return;
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (locationManager == null) return;
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 2f, locationListener, Looper.getMainLooper());
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000, 5f, locationListener, Looper.getMainLooper());
            }
            Location last = null;
            try { last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER); } catch (Exception ignored) { }
            if (last == null) try { last = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER); } catch (Exception ignored) { }
            // Only use a cached location if it is fresh and valid. A stale/default
            // cached point can be 0,0, which appears in the Atlantic and causes the
            // map to look stuck.
            if (last != null && isFreshInitialLocation(last)) handleLocation(last);
        } catch (Exception ignored) { }
    }

    private boolean isFreshInitialLocation(Location location) {
        if (location == null) return false;
        long t = location.getTime();
        // Ignore cached locations older than 10 minutes when the workout starts.
        return t > 0 && Math.abs(System.currentTimeMillis() - t) <= 10 * 60 * 1000L && isUsableLocation(location);
    }

    private boolean isUsableLocation(Location location) {
        if (location == null) return false;
        double lat = location.getLatitude();
        double lon = location.getLongitude();
        if (Double.isNaN(lat) || Double.isNaN(lon)) return false;
        if (Math.abs(lat) > 90.0 || Math.abs(lon) > 180.0) return false;
        // Reject the classic invalid/default coordinate: 0,0 in the Atlantic.
        if (Math.abs(lat) < 0.0001 && Math.abs(lon) < 0.0001) return false;
        // Allow a looser first fix so the map centers quickly, then require better accuracy.
        float maxAccuracy = lastLocation == null ? 200f : 100f;
        return !location.hasAccuracy() || location.getAccuracy() <= maxAccuracy;
    }

    private void stopLocationTracking() {
        try {
            if (locationManager != null) locationManager.removeUpdates(locationListener);
        } catch (Exception ignored) { }
    }

    private boolean hasLocationPermission() {
        return checkSelfPermissionCompat(Manifest.permission.ACCESS_FINE_LOCATION) || checkSelfPermissionCompat(Manifest.permission.ACCESS_COARSE_LOCATION);
    }

    private boolean checkSelfPermissionCompat(String permission) {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void handleLocation(Location location) {
        if (location == null || finished || paused) return;
        if (!isUsableLocation(location)) return;
        if (lastLocation != null) {
            float segment = lastLocation.distanceTo(location);
            long dt = location.getTime() - lastLocation.getTime();
            if (segment >= 0.5f && segment < 250f) {
                totalDistanceMeters += segment;
                if (location.hasSpeed()) currentSpeedKmh = Math.max(0, location.getSpeed() * 3.6);
                else if (dt > 0) currentSpeedKmh = (segment / (dt / 1000.0)) * 3.6;
            }
        }
        lastLocation = new Location(location);
        synchronized (routePoints) {
            if (routePoints.isEmpty()) routePoints.add(new RoutePoint(location.getLatitude(), location.getLongitude()));
            else {
                RoutePoint last = routePoints.get(routePoints.size() - 1);
                float[] result = new float[1];
                Location.distanceBetween(last.lat, last.lon, location.getLatitude(), location.getLongitude(), result);
                if (result[0] >= 2f) routePoints.add(new RoutePoint(location.getLatitude(), location.getLongitude()));
            }
        }
        latestSnapshot = buildSnapshot();
    }

    private String encodeRoutePoints() {
        StringBuilder builder = new StringBuilder();
        synchronized (routePoints) {
            for (int i = 0; i < routePoints.size(); i++) {
                RoutePoint p = routePoints.get(i);
                if (i > 0) builder.append('|');
                builder.append(String.format(Locale.US, "%.6f,%.6f", p.lat, p.lon));
            }
        }
        return builder.toString();
    }

    private double calculatePaceSecondsPerKm(long totalMs, double distanceMeters) {
        if (distanceMeters < 20) return 0;
        double km = distanceMeters / 1000.0;
        return (totalMs / 1000.0) / km;
    }

    private void acquireWakeLock() {
        try {
            PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (powerManager != null) {
                wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RunWalk:WorkoutTimer");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(4 * 60 * 60 * 1000L);
            }
        } catch (Exception ignored) { }
    }

    private void releaseWakeLock() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) { }
    }

    private Notification buildNotification(String title, String text) {
        Intent openIntent = finished ? new Intent(this, SummaryActivity.class) : new Intent(this, SessionActivity.class).putExtra("week", week);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent openPendingIntent = PendingIntent.getActivity(this, 99, openIntent, flags);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        builder.setSmallIcon(R.drawable.ic_runwalk_icon)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(openPendingIntent)
                .setOngoing(!finished)
                .setOnlyAlertOnce(true)
                .setColor(Color.parseColor("#00D084"));

        if (!finished) {
            Intent pauseResumeIntent = new Intent(this, WorkoutService.class);
            pauseResumeIntent.setAction(paused ? ACTION_RESUME : ACTION_PAUSE);
            PendingIntent pauseResumePending = PendingIntent.getService(this, paused ? 202 : 201, pauseResumeIntent, flags);
            builder.addAction(paused ? android.R.drawable.ic_media_play : android.R.drawable.ic_media_pause, paused ? "Resume" : "Pause", pauseResumePending);
        }
        if (Build.VERSION.SDK_INT >= 21) builder.setVisibility(Notification.VISIBILITY_PUBLIC);
        return builder.build();
    }

    private void updateNotification() {
        Snapshot s = latestSnapshot;
        if (s == null || s.finished) return;
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            String prefix = s.paused ? "Paused" : ("JOG".equals(s.intervalType) ? "Jog" : "Walk");
            String line = prefix + " • " + formatTime(s.remainingMs) + " • " + Math.round(s.calories) + " kcal • " + formatDistance(s.distanceMeters);
            manager.notify(NOTIFICATION_ID, buildNotification("RunWalk is active", line));
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "RunWalk workout", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps workout timer, sounds, and GPS tracking running when the screen is locked.");
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void playIntervalCue(String type) {
        // Voice instruction is the primary cue. The short beep is only a backup
        // so you can still notice the switch if TextToSpeech is not ready.
        speakIntervalInstruction(type);
        try {
            ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_ALARM, 55);
            int toneType = "JOG".equals(type) ? ToneGenerator.TONE_PROP_ACK : ToneGenerator.TONE_PROP_BEEP;
            tone.startTone(toneType, 180);
            handler.postDelayed(tone::release, 320);
        } catch (Exception ignored) { }
        vibrate(180);
    }

    private void initTextToSpeech() {
        try {
            textToSpeech = new TextToSpeech(getApplicationContext(), status -> {
                if (status == TextToSpeech.SUCCESS && textToSpeech != null) {
                    int result = textToSpeech.setLanguage(Locale.US);
                    textToSpeech.setSpeechRate(0.92f);
                    textToSpeech.setPitch(1.0f);
                    textToSpeechReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
                    if (textToSpeechReady && pendingSpeechType != null) {
                        String typeToSpeak = pendingSpeechType;
                        pendingSpeechType = null;
                        speakIntervalInstruction(typeToSpeak);
                    }
                }
            });
        } catch (Exception ignored) {
            textToSpeechReady = false;
        }
    }

    private void speakIntervalInstruction(String type) {
        try {
            if (textToSpeech != null && textToSpeechReady) {
                String phrase = "JOG".equals(type) ? "Jog now" : "Walk now";
                textToSpeech.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "runwalk_cue_" + SystemClock.elapsedRealtime());
            } else {
                pendingSpeechType = type;
            }
        } catch (Exception ignored) { }
    }

    private void playCountdownBeep() {
        try {
            ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_ALARM, 80);
            tone.startTone(ToneGenerator.TONE_PROP_BEEP, 130);
            handler.postDelayed(tone::release, 250);
        } catch (Exception ignored) { }
        vibrate(70);
    }

    private void playFinishedCue() {
        try {
            ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
            tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 900);
            handler.postDelayed(tone::release, 1100);
        } catch (Exception ignored) { }
        vibrate(300);
    }

    private void vibrate(long ms) {
        try {
            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator == null) return;
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            else vibrator.vibrate(ms);
        } catch (Exception ignored) { }
    }

    private String formatTime(long millis) {
        long totalSeconds = (millis + 999) / 1000;
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
    }

    private String formatDistance(double meters) {
        if (meters >= 1000) return String.format(Locale.getDefault(), "%.2f km", meters / 1000.0);
        return Math.round(meters) + " m";
    }

    private List<Interval> getIntervalsForWeek(int week) {
        switch (week) {
            case 1: return repeat(8, 60, 90);
            case 2: return repeat(7, 90, 120);
            case 3: return repeat(6, 120, 120);
            case 4: return repeat(5, 180, 120);
            case 5: return repeat(4, 300, 120);
            case 6: return repeat(3, 480, 120);
            case 7: return repeat(3, 600, 120);
            case 8:
                List<Interval> list = new ArrayList<>();
                list.add(new Interval("JOG", 25 * 60 * 1000L));
                return list;
            default: return repeat(8, 60, 90);
        }
    }

    private List<Interval> repeat(int times, int jogSeconds, int walkSeconds) {
        List<Interval> list = new ArrayList<>();
        for (int i = 0; i < times; i++) {
            list.add(new Interval("JOG", jogSeconds * 1000L));
            list.add(new Interval("WALK", walkSeconds * 1000L));
        }
        return list;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(ticker);
        stopLocationTracking();
        releaseWakeLock();
        try { if (textToSpeech != null) textToSpeech.shutdown(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    private static class Interval {
        final String type;
        final long durationMs;
        Interval(String type, long durationMs) { this.type = type; this.durationMs = durationMs; }
    }

    public static class RoutePoint {
        public final double lat;
        public final double lon;
        public RoutePoint(double lat, double lon) { this.lat = lat; this.lon = lon; }
    }

    public static class Snapshot {
        public final int week;
        public final boolean finished;
        public final boolean completed;
        public final boolean paused;
        public final String intervalType;
        public final long remainingMs;
        public final int countdownSecond;
        public final int step;
        public final int totalSteps;
        public final long totalMs;
        public final long jogMs;
        public final long walkMs;
        public final double calories;
        public final double distanceMeters;
        public final double speedKmh;
        public final double paceSecondsPerKm;

        Snapshot(int week, boolean finished, boolean completed, boolean paused, String intervalType, long remainingMs, int countdownSecond, int step, int totalSteps, long totalMs, long jogMs, long walkMs, double calories, double distanceMeters, double speedKmh, double paceSecondsPerKm) {
            this.week = week;
            this.finished = finished;
            this.completed = completed;
            this.paused = paused;
            this.intervalType = intervalType;
            this.remainingMs = remainingMs;
            this.countdownSecond = countdownSecond;
            this.step = step;
            this.totalSteps = totalSteps;
            this.totalMs = totalMs;
            this.jogMs = jogMs;
            this.walkMs = walkMs;
            this.calories = calories;
            this.distanceMeters = distanceMeters;
            this.speedKmh = speedKmh;
            this.paceSecondsPerKm = paceSecondsPerKm;
        }
    }
}
