package com.abdulla.runwalk;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private Spinner weekSpinner;
    private TextView planText;

    private final String[] weekNames = {
            "Week 1", "Week 2", "Week 3", "Week 4",
            "Week 5", "Week 6", "Week 7", "Week 8"
    };

    private final String[] planDescriptions = {
            "Jog 1:00 + Walk 1:30 × 8",
            "Jog 1:30 + Walk 2:00 × 7",
            "Jog 2:00 + Walk 2:00 × 6",
            "Jog 3:00 + Walk 2:00 × 5",
            "Jog 5:00 + Walk 2:00 × 4",
            "Jog 8:00 + Walk 2:00 × 3",
            "Jog 10:00 + Walk 2:00 × 3",
            "Jog continuously for 25:00"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestNotificationPermission();
        AlarmScheduler.scheduleWorkoutReminders(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40, 60, 40, 40);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Run / Walk Reminder");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 30);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("اختر الأسبوع وابدأ التمرين. التطبيق يعطيك صوت عند التبديل بين المشي والهرولة.");
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, 30);
        root.addView(subtitle);

        weekSpinner = new Spinner(this);
        weekSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, weekNames));
        root.addView(weekSpinner);

        planText = new TextView(this);
        planText.setTextSize(20);
        planText.setGravity(Gravity.CENTER);
        planText.setPadding(0, 35, 0, 35);
        root.addView(planText);
        updatePlanText(0);

        weekSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                updatePlanText(position);
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });

        Button startButton = new Button(this);
        startButton.setText("Start Exercise");
        startButton.setTextSize(18);
        root.addView(startButton);

        startButton.setOnClickListener(v -> {
            int week = weekSpinner.getSelectedItemPosition() + 1;
            Intent intent = new Intent(this, SessionActivity.class);
            intent.putExtra("week", week);
            startActivity(intent);
        });

        TextView reminderText = new TextView(this);
        reminderText.setText("Reminders are scheduled automatically: Monday, Wednesday, Saturday at 7:00 PM.");
        reminderText.setTextSize(14);
        reminderText.setGravity(Gravity.CENTER);
        reminderText.setPadding(0, 35, 0, 0);
        root.addView(reminderText);

        setContentView(root);
    }

    private void updatePlanText(int index) {
        planText.setText(planDescriptions[index]);
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }
}
