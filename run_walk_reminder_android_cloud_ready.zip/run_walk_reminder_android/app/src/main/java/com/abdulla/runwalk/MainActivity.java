package com.abdulla.runwalk;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "runwalk_profile";
    private Spinner weekSpinner;
    private TextView planText;
    private TextView durationText;
    private TextView repeatText;
    private TextView profileText;

    private final String[] weekNames = {
            "Week 1", "Week 2", "Week 3", "Week 4",
            "Week 5", "Week 6", "Week 7", "Week 8"
    };

    private final String[] planDescriptions = {
            "Jog 1:00  •  Walk 1:30",
            "Jog 1:30  •  Walk 2:00",
            "Jog 2:00  •  Walk 2:00",
            "Jog 3:00  •  Walk 2:00",
            "Jog 5:00  •  Walk 2:00",
            "Jog 8:00  •  Walk 2:00",
            "Jog 10:00  •  Walk 2:00",
            "Continuous jog"
    };

    private final String[] durationDescriptions = {
            "20 min", "24.5 min", "24 min", "25 min",
            "28 min", "30 min", "36 min", "25 min"
    };

    private final String[] repeatDescriptions = {
            "Repeat × 8", "Repeat × 7", "Repeat × 6", "Repeat × 5",
            "Repeat × 4", "Repeat × 3", "Repeat × 3", "One long interval"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestNotificationPermission();
        AlarmScheduler.scheduleWorkoutReminders(this);
        setupSystemBars();

        FrameLayout screen = new FrameLayout(this);

        ImageView backgroundImage = new ImageView(this);
        backgroundImage.setImageResource(R.drawable.bg_runwalk);
        backgroundImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        screen.addView(backgroundImage, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        View darkOverlay = new View(this);
        darkOverlay.setBackgroundColor(Color.parseColor("#B3000000"));
        screen.addView(darkOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scrollView.addView(root);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.app_logo);
        logo.setAdjustViewBounds(true);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(92), dp(92));
        logoParams.setMargins(0, 0, 0, dp(10));
        root.addView(logo, logoParams);

        TextView badge = new TextView(this);
        badge.setText("8-WEEK FITNESS RESET");
        badge.setTextColor(Color.parseColor("#B7FBE0"));
        badge.setTextSize(12);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(12), dp(7), dp(12), dp(7));
        badge.setBackground(makeRoundBg("#123323", dp(22), "#1EEA91", dp(1)));
        root.addView(badge, wrapParams());

        TextView title = new TextView(this);
        title.setText("RunWalk");
        title.setTextColor(Color.WHITE);
        title.setTextSize(38);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(18), 0, dp(6));
        root.addView(title, matchWrapParams());

        TextView subtitle = new TextView(this);
        subtitle.setText("رجعة تدريجية للركض بعد الانقطاع\nمع تنبيه صوتي وقت التبديل بين المشي والهرولة");
        subtitle.setTextColor(Color.parseColor("#B9C6D6"));
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setLineSpacing(dp(2), 1.0f);
        root.addView(subtitle, matchWrapParams());

        LinearLayout profileCard = new LinearLayout(this);
        profileCard.setOrientation(LinearLayout.VERTICAL);
        profileCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        profileCard.setBackground(makeRoundBg("#101F31", dp(22), "#29415D", dp(1)));
        LinearLayout.LayoutParams profileParams = matchWrapParams();
        profileParams.setMargins(0, dp(22), 0, 0);
        root.addView(profileCard, profileParams);

        TextView profileTitle = new TextView(this);
        profileTitle.setText("Profile for calories");
        profileTitle.setTextColor(Color.WHITE);
        profileTitle.setTextSize(17);
        profileTitle.setTypeface(Typeface.DEFAULT_BOLD);
        profileCard.addView(profileTitle, matchWrapParams());

        profileText = new TextView(this);
        profileText.setTextColor(Color.parseColor("#B9C6D6"));
        profileText.setTextSize(14);
        profileText.setPadding(0, dp(6), 0, dp(10));
        profileCard.addView(profileText, matchWrapParams());

        Button editProfileButton = new Button(this);
        editProfileButton.setText("Edit weight / age / height / gender");
        editProfileButton.setAllCaps(false);
        editProfileButton.setTextColor(Color.WHITE);
        editProfileButton.setBackground(makeRoundBg("#223248", dp(18), null, 0));
        profileCard.addView(editProfileButton, matchHeightParams(dp(48)));
        editProfileButton.setOnClickListener(v -> showProfileDialog(false, null));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(makeGradientBg("#102033", "#0B1728", dp(24)));
        LinearLayout.LayoutParams cardParams = matchWrapParams();
        cardParams.setMargins(0, dp(18), 0, 0);
        root.addView(card, cardParams);

        TextView choose = new TextView(this);
        choose.setText("اختر الأسبوع");
        choose.setTextColor(Color.WHITE);
        choose.setTextSize(18);
        choose.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(choose, matchWrapParams());

        weekSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, weekNames);
        weekSpinner.setAdapter(adapter);
        weekSpinner.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams spinnerParams = matchWrapParams();
        spinnerParams.setMargins(0, dp(12), 0, dp(14));
        card.addView(weekSpinner, spinnerParams);

        planText = new TextView(this);
        planText.setTextColor(Color.WHITE);
        planText.setTextSize(24);
        planText.setTypeface(Typeface.DEFAULT_BOLD);
        planText.setGravity(Gravity.CENTER);
        planText.setPadding(0, dp(12), 0, dp(6));
        card.addView(planText, matchWrapParams());

        LinearLayout infoRow = new LinearLayout(this);
        infoRow.setOrientation(LinearLayout.HORIZONTAL);
        infoRow.setGravity(Gravity.CENTER);
        infoRow.setPadding(0, dp(10), 0, dp(6));
        card.addView(infoRow, matchWrapParams());

        durationText = makeMiniStat();
        repeatText = makeMiniStat();
        infoRow.addView(durationText, weightedParams());
        infoRow.addView(repeatText, weightedParams());

        updatePlanText(0);
        updateProfileText();

        weekSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updatePlanText(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        Button startButton = new Button(this);
        startButton.setText("START EXERCISE");
        startButton.setTextSize(18);
        startButton.setTypeface(Typeface.DEFAULT_BOLD);
        startButton.setTextColor(Color.parseColor("#07111F"));
        startButton.setAllCaps(false);
        startButton.setBackground(makeRoundBg("#00D084", dp(22), null, 0));
        LinearLayout.LayoutParams startParams = matchHeightParams(dp(58));
        startParams.setMargins(0, dp(22), 0, 0);
        root.addView(startButton, startParams);

        startButton.setOnClickListener(v -> {
            int week = weekSpinner.getSelectedItemPosition() + 1;
            if (!hasProfile()) {
                showProfileDialog(true, () -> startSession(week));
            } else {
                startSession(week);
            }
        });

        TextView reminderText = new TextView(this);
        reminderText.setText("Reminders: Monday • Wednesday • Saturday at 7:00 PM");
        reminderText.setTextColor(Color.parseColor("#7F8FA3"));
        reminderText.setTextSize(13);
        reminderText.setGravity(Gravity.CENTER);
        reminderText.setPadding(0, dp(18), 0, 0);
        root.addView(reminderText, matchWrapParams());

        screen.addView(scrollView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        setContentView(screen);

        if (!hasProfile()) {
            scrollView.postDelayed(() -> showProfileDialog(false, null), 400);
        }
    }

    private void startSession(int week) {
        Intent intent = new Intent(this, SessionActivity.class);
        intent.putExtra("week", week);
        startActivity(intent);
    }

    private TextView makeMiniStat() {
        TextView view = new TextView(this);
        view.setTextColor(Color.parseColor("#B7FBE0"));
        view.setTextSize(15);
        view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(10), dp(12), dp(10), dp(12));
        view.setBackground(makeRoundBg("#123323", dp(18), "#244B39", dp(1)));
        return view;
    }

    private void updatePlanText(int index) {
        planText.setText(planDescriptions[index]);
        durationText.setText(durationDescriptions[index]);
        repeatText.setText(repeatDescriptions[index]);
    }

    private boolean hasProfile() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("profile_set", false);
    }

    private void updateProfileText() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean("profile_set", false)) {
            profileText.setText("Not set yet. Add your data for better calorie estimate.");
            return;
        }
        float weight = prefs.getFloat("weight_kg", 0f);
        int age = prefs.getInt("age", 0);
        int height = prefs.getInt("height_cm", 0);
        String gender = prefs.getString("gender", "Male");
        profileText.setText(String.format("%.1f kg  •  %d years  •  %d cm  •  %s", weight, age, height, gender));
    }

    private void showProfileDialog(boolean requiredBeforeStart, Runnable afterSave) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(18);
        layout.setPadding(pad, dp(8), pad, 0);

        TextView note = new TextView(this);
        note.setText("Used only to estimate calories. No goal field added.");
        note.setTextColor(Color.DKGRAY);
        note.setPadding(0, 0, 0, dp(10));
        layout.addView(note, matchWrapParams());

        EditText weightInput = makeNumberInput("Weight kg", prefs.getFloat("weight_kg", 0f) > 0 ? String.valueOf(prefs.getFloat("weight_kg", 0f)) : "");
        EditText ageInput = makeNumberInput("Age", prefs.getInt("age", 0) > 0 ? String.valueOf(prefs.getInt("age", 0)) : "");
        EditText heightInput = makeNumberInput("Height cm", prefs.getInt("height_cm", 0) > 0 ? String.valueOf(prefs.getInt("height_cm", 0)) : "");
        layout.addView(weightInput, matchWrapParams());
        layout.addView(ageInput, matchWrapParams());
        layout.addView(heightInput, matchWrapParams());

        Spinner genderSpinner = new Spinner(this);
        String[] genders = {"Male", "Female"};
        genderSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, genders));
        String savedGender = prefs.getString("gender", "Male");
        genderSpinner.setSelection("Female".equals(savedGender) ? 1 : 0);
        layout.addView(genderSpinner, matchWrapParams());

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(requiredBeforeStart ? "Profile required" : "Calorie profile")
                .setView(layout)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                float weight = Float.parseFloat(weightInput.getText().toString().trim());
                int age = Integer.parseInt(ageInput.getText().toString().trim());
                int height = Integer.parseInt(heightInput.getText().toString().trim());
                if (weight < 25 || weight > 250 || age < 8 || age > 100 || height < 90 || height > 240) {
                    Toast.makeText(this, "Check the numbers again", Toast.LENGTH_SHORT).show();
                    return;
                }
                prefs.edit()
                        .putBoolean("profile_set", true)
                        .putFloat("weight_kg", weight)
                        .putInt("age", age)
                        .putInt("height_cm", height)
                        .putString("gender", genderSpinner.getSelectedItem().toString())
                        .apply();
                updateProfileText();
                dialog.dismiss();
                if (afterSave != null) afterSave.run();
            } catch (Exception e) {
                Toast.makeText(this, "Enter valid numbers", Toast.LENGTH_SHORT).show();
            }
        }));

        dialog.show();
    }

    private EditText makeNumberInput(String hint, String value) {
        EditText editText = new EditText(this);
        editText.setHint(hint);
        editText.setText(value);
        editText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        editText.setSingleLine(true);
        editText.setPadding(0, dp(8), 0, dp(8));
        return editText;
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    private void setupSystemBars() {
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.setStatusBarColor(Color.parseColor("#07111F"));
            window.setNavigationBarColor(Color.parseColor("#07111F"));
        }
    }

    private GradientDrawable makeRoundBg(String color, int radius, String strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.parseColor(color));
        drawable.setCornerRadius(radius);
        if (strokeColor != null) drawable.setStroke(strokeWidth, Color.parseColor(strokeColor));
        return drawable;
    }

    private GradientDrawable makeGradientBg(String start, String end, int radius) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor(start), Color.parseColor(end)}
        );
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), Color.parseColor("#1D314B"));
        return drawable;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams matchWrapParams() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams wrapParams() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchHeightParams(int height) {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height);
    }

    private LinearLayout.LayoutParams weightedParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        params.setMargins(dp(4), 0, dp(4), 0);
        return params;
    }
}
