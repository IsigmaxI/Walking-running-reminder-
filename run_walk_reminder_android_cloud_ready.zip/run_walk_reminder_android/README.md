# Run Walk Reminder Android App

This is a simple native Android app for the 8-week run/walk plan.

## Features
- Select Week 1 to Week 8.
- Start the workout session.
- A loud alarm tone plays whenever you must switch between WALK and JOG.
- Workout reminders are scheduled automatically on Monday, Wednesday, and Saturday at 7:00 PM.

## How to open
1. Unzip the file.
2. Open Android Studio.
3. Choose **Open**.
4. Select the folder `run_walk_reminder_android`.
5. Let Gradle sync.
6. Press **Run** to install on your Android phone.

## Edit workout times
Open:
`app/src/main/java/com/abdulla/runwalk/SessionActivity.java`

Then edit the method:
`getIntervalsForWeek()`

## Edit reminder days/time
Open:
`app/src/main/java/com/abdulla/runwalk/AlarmScheduler.java`

Current reminder schedule:
- Monday 7:00 PM
- Wednesday 7:00 PM
- Saturday 7:00 PM
