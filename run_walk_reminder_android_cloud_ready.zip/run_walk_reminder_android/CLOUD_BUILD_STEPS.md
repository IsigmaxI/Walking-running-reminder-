# Cloud build طريقة سحابية لإخراج APK

هذه النسخة فيها ملف GitHub Actions جاهز:
`.github/workflows/build-apk.yml`

## الخطوات

1. افتح GitHub من الكمبيوتر أو من المتصفح في الهاتف.
2. سوِّ Repository جديد.
3. ارفع ملفات هذا المشروع كاملة داخل الـ Repository.
4. ادخل تبويب **Actions**.
5. افتح Workflow اسمه **Build Android APK**.
6. اضغط **Run workflow**.
7. انتظر لين يخلص البناء.
8. افتح آخر Run، وانزل إلى **Artifacts**.
9. حمّل ملف **RunWalkReminder-debug-apk**.
10. فك الضغط وستحصل على: `app-debug.apk`.
11. انقل APK لتلفونك وثبته.

## ملاحظة مهمة

هذا APK Debug. مناسب للتجربة الشخصية على جهازك، وليس للنشر في Google Play.
قد تحتاج في الهاتف تفعيل: **Install unknown apps** للمتصفح أو مدير الملفات.
