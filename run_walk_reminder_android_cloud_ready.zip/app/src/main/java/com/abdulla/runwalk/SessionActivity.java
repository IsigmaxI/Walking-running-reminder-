package com.abdulla.runwalk;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Polyline;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SessionActivity extends Activity {
    private static final int LOCATION_PERMISSION_REQUEST = 302;
    private TextView intervalText;
    private TextView timerText;
    private TextView stepText;
    private TextView caloriesText;
    private TextView distanceText;
    private TextView paceText;
    private TextView speedText;
    private TextView gpsText;
    private TextView hintText;
    private TextView stopConfirmText;
    private ProgressBar progressBar;
    private LinearLayout stopConfirmBox;
    private Button pauseButton;
    private MapView mapView;
    private Polyline routeLine;
    private int week = 1;
    private boolean isStopping = false;
    private boolean summaryOpened = false;
    private boolean serviceStarted = false;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    private final Runnable uiTicker = new Runnable() {
        @Override
        public void run() {
            updateFromService();
            updateMapRoute();
            if (!summaryOpened) uiHandler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupSystemBars();
        Configuration.getInstance().load(getApplicationContext(), getSharedPreferences("osmdroid", MODE_PRIVATE));
        Configuration.getInstance().setUserAgentValue(getPackageName());

        week = getIntent().getIntExtra("week", 1);
        buildUi();

        // Important: do not start the workout service until the location permission
        // dialog has been answered. If the service starts before permission is granted,
        // GPS tracking won't subscribe and the map may remain at the default 0,0 point.
        if (hasLocationPermission()) {
            startWorkoutServiceIfNeeded();
        } else {
            requestLocationPermissionIfNeeded();
        }
        uiHandler.post(uiTicker);
    }

    private void buildUi() {
        FrameLayout screen = new FrameLayout(this);

        ImageView backgroundImage = new ImageView(this);
        backgroundImage.setImageResource(R.drawable.bg_runwalk);
        backgroundImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        screen.addView(backgroundImage, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        View darkOverlay = new View(this);
        darkOverlay.setBackgroundColor(Color.parseColor("#C8000000"));
        screen.addView(darkOverlay, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        // Large bottom padding keeps Stop/Confirm controls above Android navigation buttons.
        root.setPadding(dp(16), dp(16), dp(16), dp(170));
        scrollView.setClipToPadding(false);
        scrollView.addView(root);

        TextView title = new TextView(this);
        title.setText("Week " + week + " Session");
        title.setTextColor(Color.parseColor("#B9C6D6"));
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(6));
        root.addView(title, matchWrapParams());

        intervalText = new TextView(this);
        intervalText.setTextSize(36);
        intervalText.setTypeface(Typeface.DEFAULT_BOLD);
        intervalText.setGravity(Gravity.CENTER);
        intervalText.setPadding(0, dp(12), 0, dp(12));
        root.addView(intervalText, matchWrapParams());

        timerText = new TextView(this);
        timerText.setTextColor(Color.WHITE);
        timerText.setTextSize(52);
        timerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        timerText.setGravity(Gravity.CENTER);
        timerText.setPadding(0, dp(8), 0, dp(4));
        root.addView(timerText, matchWrapParams());

        stepText = new TextView(this);
        stepText.setTextColor(Color.parseColor("#B9C6D6"));
        stepText.setTextSize(16);
        stepText.setGravity(Gravity.CENTER);
        stepText.setPadding(0, 0, 0, dp(8));
        root.addView(stepText, matchWrapParams());

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(16);
        LinearLayout.LayoutParams progressParams = matchHeightParams(dp(9));
        progressParams.setMargins(0, dp(2), 0, dp(8));
        root.addView(progressBar, progressParams);

        LinearLayout statsGrid = new LinearLayout(this);
        statsGrid.setOrientation(LinearLayout.VERTICAL);
        root.addView(statsGrid, matchWrapParams());

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        statsGrid.addView(row1, matchWrapParams());
        caloriesText = makeStatText();
        distanceText = makeStatText();
        row1.addView(caloriesText, weightedParams());
        row1.addView(distanceText, weightedParams());

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        statsGrid.addView(row2, matchWrapParams());
        paceText = makeStatText();
        speedText = makeStatText();
        row2.addView(paceText, weightedParams());
        row2.addView(speedText, weightedParams());

        gpsText = new TextView(this);
        gpsText.setText("GPS: Waiting");
        gpsText.setTextColor(Color.parseColor("#B9C6D6"));
        gpsText.setTextSize(13);
        gpsText.setGravity(Gravity.CENTER);
        gpsText.setPadding(0, dp(6), 0, dp(2));
        root.addView(gpsText, matchWrapParams());

        mapView = new MapView(this);
        mapView.setTileSource(TileSourceFactory.MAPNIK);
        mapView.setMultiTouchControls(true);
        mapView.getController().setZoom(15.0);
        // Default to Abu Dhabi instead of the map library default near 0,0 in the Atlantic.
        // Once a real GPS fix arrives, the map recenters to the user's actual location.
        mapView.getController().setCenter(new GeoPoint(24.4539, 54.3773));
        mapView.setBackgroundColor(Color.parseColor("#0B1728"));
        routeLine = new Polyline(mapView);
        routeLine.setColor(Color.parseColor("#00D084"));
        routeLine.setWidth(dp(5));
        mapView.getOverlays().add(routeLine);
        LinearLayout.LayoutParams mapParams = matchHeightParams(dp(118));
        mapParams.setMargins(0, dp(4), 0, dp(6));
        root.addView(mapView, mapParams);

        hintText = new TextView(this);
        hintText.setTextColor(Color.parseColor("#8EA0B6"));
        hintText.setTextSize(13);
        hintText.setGravity(Gravity.CENTER);
        hintText.setPadding(dp(10), dp(9), dp(10), dp(9));
        hintText.setBackground(makeRoundBg("#102033", dp(18), "#1D314B", dp(1)));
        root.addView(hintText, matchWrapParams());

        pauseButton = new Button(this);
        pauseButton.setText("Pause");
        pauseButton.setTextSize(17);
        pauseButton.setTypeface(Typeface.DEFAULT_BOLD);
        pauseButton.setAllCaps(false);
        pauseButton.setTextColor(Color.parseColor("#07111F"));
        pauseButton.setBackground(makeRoundBg("#FFB020", dp(22), null, 0));
        LinearLayout.LayoutParams pauseParams = matchHeightParams(dp(48));
        pauseParams.setMargins(0, dp(10), 0, 0);
        root.addView(pauseButton, pauseParams);
        pauseButton.setOnClickListener(v -> togglePauseResume());

        Button stopButton = new Button(this);
        stopButton.setText("Stop Session");
        stopButton.setTextSize(17);
        stopButton.setTypeface(Typeface.DEFAULT_BOLD);
        stopButton.setTextColor(Color.WHITE);
        stopButton.setAllCaps(false);
        stopButton.setBackground(makeRoundBg("#D94040", dp(22), null, 0));
        LinearLayout.LayoutParams stopParams = matchHeightParams(dp(48));
        stopParams.setMargins(0, dp(10), 0, 0);
        root.addView(stopButton, stopParams);
        stopButton.setOnClickListener(v -> showStopConfirmation());

        stopConfirmBox = new LinearLayout(this);
        stopConfirmBox.setOrientation(LinearLayout.VERTICAL);
        stopConfirmBox.setPadding(dp(16), dp(14), dp(16), dp(16));
        stopConfirmBox.setBackground(makeRoundBg("#25151A", dp(22), "#FF6B6B", dp(1)));
        stopConfirmBox.setVisibility(View.GONE);
        LinearLayout.LayoutParams confirmParams = matchWrapParams();
        confirmParams.setMargins(0, dp(14), 0, 0);

        stopConfirmText = new TextView(this);
        stopConfirmText.setText("اسحب السلايدر للآخر لتأكيد إيقاف التمرين");
        stopConfirmText.setTextColor(Color.WHITE);
        stopConfirmText.setTextSize(15);
        stopConfirmText.setGravity(Gravity.CENTER);
        stopConfirmText.setPadding(0, 0, 0, dp(10));
        stopConfirmBox.addView(stopConfirmText, matchWrapParams());

        SeekBar stopSlider = new SeekBar(this);
        stopSlider.setMax(100);
        stopSlider.setProgress(0);
        stopConfirmBox.addView(stopSlider, matchHeightParams(dp(48)));
        stopSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { if (fromUser && progress >= 96) confirmStopAndOpenSummary(); }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                if (!isStopping && seekBar.getProgress() < 96) {
                    seekBar.setProgress(0);
                    stopConfirmText.setText("اسحب السلايدر للآخر لتأكيد إيقاف التمرين");
                }
            }
        });

        Button cancelStopButton = new Button(this);
        cancelStopButton.setText("Cancel");
        cancelStopButton.setTextSize(15);
        cancelStopButton.setAllCaps(false);
        cancelStopButton.setTextColor(Color.WHITE);
        cancelStopButton.setBackground(makeRoundBg("#223248", dp(18), null, 0));
        LinearLayout.LayoutParams cancelParams = matchHeightParams(dp(46));
        cancelParams.setMargins(0, dp(8), 0, 0);
        stopConfirmBox.addView(cancelStopButton, cancelParams);
        cancelStopButton.setOnClickListener(v -> { stopSlider.setProgress(0); stopConfirmBox.setVisibility(View.GONE); });
        root.addView(stopConfirmBox, confirmParams);

        screen.addView(scrollView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(screen);
    }

    private TextView makeStatText() {
        TextView view = new TextView(this);
        view.setTextColor(Color.WHITE);
        view.setTextSize(13);
        view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(6), dp(7), dp(6), dp(7));
        view.setBackground(makeRoundBg("#80102033", dp(16), "#263B56", dp(1)));
        return view;
    }

    private void requestLocationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 23 && !hasLocationPermission()) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION_REQUEST);
        }
    }

    private boolean hasLocationPermission() {
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            // Start the workout after the user answers the permission dialog.
            // If permission is denied, the timer still works; only GPS route tracking is disabled.
            startWorkoutServiceIfNeeded();
        }
    }

    private void startWorkoutServiceIfNeeded() {
        if (serviceStarted || WorkoutService.isRunning()) return;
        serviceStarted = true;
        Intent intent = new Intent(this, WorkoutService.class);
        intent.setAction(WorkoutService.ACTION_START);
        intent.putExtra("week", week);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
        else startService(intent);
    }

    private void togglePauseResume() {
        WorkoutService.Snapshot s = WorkoutService.getSnapshot();
        Intent intent = new Intent(this, WorkoutService.class);
        intent.setAction(s != null && s.paused ? WorkoutService.ACTION_RESUME : WorkoutService.ACTION_PAUSE);
        startService(intent);
    }

    private void updateFromService() {
        WorkoutService.Snapshot s = WorkoutService.getSnapshot();
        if (s == null) {
            intervalText.setText("READY");
            timerText.setText("00:00");
            stepText.setText("Starting timer...");
            caloriesText.setText("Calories\n0 kcal");
            distanceText.setText("Distance\n0 m");
            paceText.setText("Pace\n--");
            speedText.setText("Speed\n0.0 km/h");
            if (gpsText != null) gpsText.setText("GPS: Waiting");
            hintText.setText(hasLocationPermission() ? "جاري انتظار تثبيت إشارة GPS... افتح المكان للسماء إذا كنت داخل مبنى" : "اسمح بصلاحية الموقع لتفعيل تتبع GPS.");
            return;
        }
        if (s.finished) {
            openSummaryOnce();
            return;
        }

        boolean isJog = "JOG".equals(s.intervalType);
        int accent = Color.parseColor(isJog ? "#00D084" : "#FFB020");
        int darkCard = Color.parseColor(isJog ? "#123323" : "#3A2912");
        intervalText.setText(s.paused ? "PAUSED" : (isJog ? "JOG" : "WALK"));
        intervalText.setTextColor(s.paused ? Color.parseColor("#FFB020") : accent);
        intervalText.setBackground(makeRoundBg(String.format("#%06X", (0xFFFFFF & darkCard)), dp(28), isJog ? "#1EEA91" : "#FFC45D", dp(1)));
        timerText.setText(formatTime(s.remainingMs));
        stepText.setText("Step " + s.step + " of " + s.totalSteps);
        caloriesText.setText("Calories\n" + Math.round(s.calories) + " kcal");
        distanceText.setText("Distance\n" + formatDistance(s.distanceMeters));
        paceText.setText("Pace\n" + formatPace(s.paceSecondsPerKm));
        speedText.setText("Speed\n" + String.format(Locale.getDefault(), "%.1f km/h", s.speedKmh));
        if (gpsText != null) gpsText.setText("GPS: " + (s.gpsStatus == null ? "Waiting" : s.gpsStatus));
        progressBar.setMax(Math.max(1, s.totalSteps));
        progressBar.setProgress(Math.max(1, s.step));
        pauseButton.setText(s.paused ? "Resume" : "Pause");
        if (s.paused) hintText.setText("تم إيقاف التمرين مؤقتاً — اضغط Resume للتكملة");
        else if (s.distanceMeters < 2 && s.gpsStatus != null && !s.gpsStatus.startsWith("GPS Good")) hintText.setText("ثبّت إشارة GPS أولاً — المسافة لن تُحسب إلا بعد دقة جيدة");
        else if (s.countdownSecond > 0) hintText.setText("التبديل خلال " + s.countdownSecond + " ثواني");
        else hintText.setText(isJog ? "هرولة خفيفة — لا تسرع، خلك قادر تتكلم" : "مشي وهدّي النفس — استعد للتبديل القادم");
    }

    private void updateMapRoute() {
        if (mapView == null || routeLine == null) return;
        List<WorkoutService.RoutePoint> points = WorkoutService.getTrackPoints();
        if (points.isEmpty()) return;
        List<GeoPoint> geoPoints = new ArrayList<>();
        for (WorkoutService.RoutePoint p : points) geoPoints.add(new GeoPoint(p.lat, p.lon));
        routeLine.setPoints(geoPoints);
        GeoPoint last = geoPoints.get(geoPoints.size() - 1);
        mapView.getController().setCenter(last);
        mapView.invalidate();
    }

    private void showStopConfirmation() {
        if (stopConfirmBox.getVisibility() == View.VISIBLE) {
            stopConfirmText.setText("اسحب السلايدر للآخر لتأكيد إيقاف التمرين");
            return;
        }
        stopConfirmBox.setVisibility(View.VISIBLE);
        stopConfirmText.setText("اسحب السلايدر للآخر لتأكيد إيقاف التمرين");
    }

    private void confirmStopAndOpenSummary() {
        if (isStopping) return;
        isStopping = true;
        Intent intent = new Intent(this, WorkoutService.class);
        intent.setAction(WorkoutService.ACTION_STOP);
        startService(intent);
        uiHandler.postDelayed(this::openSummaryOnce, 700);
    }

    private void openSummaryOnce() {
        if (summaryOpened) return;
        summaryOpened = true;
        uiHandler.removeCallbacks(uiTicker);
        startActivity(new Intent(this, SummaryActivity.class));
        finish();
    }

    @Override protected void onResume() { super.onResume(); if (mapView != null) mapView.onResume(); }
    @Override protected void onPause() { if (mapView != null) mapView.onPause(); super.onPause(); }
    @Override protected void onDestroy() { uiHandler.removeCallbacks(uiTicker); if (mapView != null) mapView.onDetach(); super.onDestroy(); }

    private String formatTime(long millis) {
        long totalSeconds = (millis + 999) / 1000;
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
    }

    private String formatDistance(double meters) {
        if (meters >= 1000) return String.format(Locale.getDefault(), "%.2f km", meters / 1000.0);
        return Math.round(meters) + " m";
    }

    private String formatPace(double secondsPerKm) {
        if (secondsPerKm <= 0) return "--";
        long sec = Math.round(secondsPerKm);
        return String.format(Locale.getDefault(), "%d:%02d min/km", sec / 60, sec % 60);
    }

    private void setupSystemBars() {
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(true);
            window.setStatusBarColor(Color.parseColor("#07111F"));
            window.setNavigationBarColor(Color.parseColor("#07111F"));
        }
    }

    private GradientDrawable makeRoundBg(String color, int radius, String strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.parseColor(color));
        drawable.setCornerRadius(radius);
        if (strokeColor != null) drawable.setStroke(strokeWidth, Color.parseColor(strokeColor));
        return drawable;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout.LayoutParams matchWrapParams() { return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams matchHeightParams(int height) { return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height); }
    private LinearLayout.LayoutParams weightedParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        params.setMargins(dp(3), dp(3), dp(3), dp(3));
        return params;
    }
}
